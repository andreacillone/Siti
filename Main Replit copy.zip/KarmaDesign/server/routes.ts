import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all products
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  // Get single product
  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Search products
  app.get("/api/search", async (req, res) => {
    try {
      const searchSchema = z.object({
        name: z.string().optional(),
        idCode: z.string().optional(),
        number: z.string().optional(),
      });

      const query = searchSchema.parse(req.query);
      const products = await storage.searchProducts(query);
      res.json(products);
    } catch (error) {
      res.status(400).json({ error: "Invalid search parameters" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
