import { type User, type InsertUser, type Product, type InsertProduct } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  getProductByIdCode(idCode: string): Promise<Product | undefined>;
  searchProducts(query: { name?: string; idCode?: string; number?: string }): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.initializeProducts();
  }

  private initializeProducts() {
    const sampleProducts: Product[] = [
      {
        id: "1",
        name: "DATSUN",
        year: 2025,
        isAvailable: true,
        idCode: "KAR25001",
        frameUsed: "SANNAHED 13×18",
        dimensions: "22×26×6 cm",
        mainImage: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        frontImage: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        backImage: "https://images.unsplash.com/photo-1494905998402-395d579af36f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        detailImage: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        instagramLink: "#",
        tiktokLink: "#",
        facebookLink: "#",
      },
      {
        id: "2",
        name: "PORSCHE",
        year: 2025,
        isAvailable: true,
        idCode: "KAR25002",
        frameUsed: "SANNAHED 13×18",
        dimensions: "22×26×6 cm",
        mainImage: "https://images.unsplash.com/photo-1544829020-7856c2d14544?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        frontImage: "https://images.unsplash.com/photo-1544829020-7856c2d14544?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        backImage: "https://images.unsplash.com/photo-1494905998402-395d579af36f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        detailImage: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        instagramLink: "#",
        tiktokLink: "#",
        facebookLink: "#",
      },
      {
        id: "3",
        name: "FERRARI",
        year: 2025,
        isAvailable: false,
        idCode: "KAR25003",
        frameUsed: "SANNAHED 13×18",
        dimensions: "22×26×6 cm",
        mainImage: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        frontImage: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        backImage: "https://images.unsplash.com/photo-1494905998402-395d579af36f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        detailImage: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        instagramLink: "#",
        tiktokLink: "#",
        facebookLink: "#",
      },
      {
        id: "4",
        name: "LAMBORGHINI",
        year: 2025,
        isAvailable: true,
        idCode: "KAR25004",
        frameUsed: "SANNAHED 13×18",
        dimensions: "22×26×6 cm",
        mainImage: "https://images.unsplash.com/photo-1583121274602-3e2820c69888?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        frontImage: "https://images.unsplash.com/photo-1583121274602-3e2820c69888?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        backImage: "https://images.unsplash.com/photo-1494905998402-395d579af36f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        detailImage: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        instagramLink: "#",
        tiktokLink: "#",
        facebookLink: "#",
      },
      {
        id: "5",
        name: "MUSTANG",
        year: 2025,
        isAvailable: true,
        idCode: "KAR25005",
        frameUsed: "SANNAHED 13×18",
        dimensions: "22×26×6 cm",
        mainImage: "https://images.unsplash.com/photo-1494905998402-395d579af36f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        frontImage: "https://images.unsplash.com/photo-1494905998402-395d579af36f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        backImage: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        detailImage: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        instagramLink: "#",
        tiktokLink: "#",
        facebookLink: "#",
      },
      {
        id: "6",
        name: "CORVETTE",
        year: 2025,
        isAvailable: false,
        idCode: "KAR25006",
        frameUsed: "SANNAHED 13×18",
        dimensions: "22×26×6 cm",
        mainImage: "https://images.unsplash.com/photo-1563720223185-11003d516935?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        frontImage: "https://images.unsplash.com/photo-1563720223185-11003d516935?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        backImage: "https://images.unsplash.com/photo-1494905998402-395d579af36f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        detailImage: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
        instagramLink: "#",
        tiktokLink: "#",
        facebookLink: "#",
      }
    ];

    sampleProducts.forEach(product => {
      this.products.set(product.id, product);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductByIdCode(idCode: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.idCode === idCode,
    );
  }

  async searchProducts(query: { name?: string; idCode?: string; number?: string }): Promise<Product[]> {
    const allProducts = Array.from(this.products.values());
    
    return allProducts.filter(product => {
      const nameMatch = !query.name || product.name.toLowerCase().includes(query.name.toLowerCase());
      const idMatch = !query.idCode || product.idCode.toLowerCase().includes(query.idCode.toLowerCase());
      const numberMatch = !query.number || product.idCode.includes(query.number);
      
      return nameMatch && idMatch && numberMatch;
    });
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { ...insertProduct, id };
    this.products.set(id, product);
    return product;
  }
}

export const storage = new MemStorage();
