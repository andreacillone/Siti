import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  year: integer("year").notNull(),
  isAvailable: boolean("is_available").notNull().default(true),
  idCode: text("id_code").notNull().unique(),
  frameUsed: text("frame_used").notNull(),
  dimensions: text("dimensions").notNull(),
  mainImage: text("main_image").notNull(),
  frontImage: text("front_image"),
  backImage: text("back_image"),
  detailImage: text("detail_image"),
  instagramLink: text("instagram_link"),
  tiktokLink: text("tiktok_link"),
  facebookLink: text("facebook_link"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;
