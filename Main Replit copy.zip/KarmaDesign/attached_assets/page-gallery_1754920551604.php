
<?php
/* Template Name: Gallery */
get_header(); ?>
<div class="container">
  <h2 style="text-transform:uppercase;letter-spacing:.06em;">Gallery</h2>
  <?php
  $args = [
    'post_type' => 'product',
    'posts_per_page' => 12,
    'paged' => max(1, get_query_var('paged'))
  ];
  $q = new WP_Query($args);
  if($q->have_posts()): ?>
    <div class="grid grid-4">
      <?php while($q->have_posts()): $q->the_post();
        global $product; ?>
        <a class="card product-card" href="<?php the_permalink(); ?>">
          <div class="thumb"><?php echo woocommerce_get_product_thumbnail('large'); ?></div>
          <div class="meta">
            <div class="name"><?php the_title(); ?></div>
            <?php if($product && !$product->is_in_stock()): ?>
              <span class="badge soldout">Sold Out</span>
            <?php else: ?>
              <span class="badge available">Available</span>
            <?php endif; ?>
          </div>
        </a>
      <?php endwhile; ?>
    </div>
    <div style="text-align:center;margin:24px 0;">
      <?php
      echo paginate_links([
        'total' => $q->max_num_pages,
        'prev_text' => '&lsaquo;',
        'next_text' => '&rsaquo;'
      ]);
      ?>
    </div>
  <?php else: ?>
    <p>No products yet.</p>
  <?php endif; wp_reset_postdata(); ?>
</div>
<?php get_footer(); ?>
