
<?php
/* Template Name: Support */
get_header(); ?>
<div class="container grid" style="grid-template-columns:1fr 1fr;">
  <section>
    <h2 style="text-transform:uppercase;letter-spacing:.06em;">Contact Us</h2>
    <p><strong>Email:</strong> <a href="mailto:karmaprojects2@gmail.com">karmaprojects2@gmail.com</a></p>
    <p><strong>Support hours:</strong> Monday–Saturday, 08:00–19:00 (UTC+1)</p>
    <div class="social" style="margin-top:16px;">
      <a href="#" aria-label="Instagram">IG</a>
      <a href="#" aria-label="TikTok">TT</a>
      <a href="#" aria-label="Facebook">FB</a>
      <a href="#" aria-label="Vinted">V</a>
    </div>
  </section>
  <section>
    <h2 style="text-transform:uppercase;letter-spacing:.06em;">Frequently Asked Questions</h2>
    <div class="k-accordions">
      <details><summary>How long does it take to ship?</summary><div>Most orders ship within 3–5 business days.</div></details>
      <details><summary>Are all pieces unique?</summary><div>Yes. Every frame is 1/1 and never repeated.</div></details>
      <details><summary>Do you ship internationally?</summary><div>Yes, worldwide.</div></details>
    </div>
  </section>
</div>
<?php get_footer(); ?>
