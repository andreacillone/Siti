<?php
/** Fallback index template */
get_header(); ?>
<div class="container">
  <h2>Page</h2>
  <div class="card" style="padding:20px;">
    <?php if (have_posts()): while(have_posts()): the_post(); the_content(); endwhile; else: ?>
      <p>No content yet.</p>
    <?php endif; ?>
  </div>
</div>
<?php get_footer(); ?>
