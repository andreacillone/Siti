
</div><!-- .site-content -->
<footer class="footer">
  <div class="container row">
    <div class="social">
      <a href="<?php echo esc_url( karma_social_url('instagram') ); ?>" aria-label="Instagram">IG</a>
      <a href="<?php echo esc_url( karma_social_url('tiktok') ); ?>" aria-label="TikTok">TT</a>
      <a href="<?php echo esc_url( karma_social_url('youtube') ); ?>" aria-label="YouTube Shorts">YT</a>
      <a href="<?php echo esc_url( karma_social_url('facebook') ); ?>" aria-label="Facebook">FB</a>
    </div>
    <div>© 2025 Karma</div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
