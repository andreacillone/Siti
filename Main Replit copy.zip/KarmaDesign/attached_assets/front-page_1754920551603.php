
<?php get_header(); ?>
<section class="home-hero" style="display:flex;align-items:center;justify-content:center;min-height:calc(100vh - 64px);">
  <div class="card" style="padding:0; border-radius:22px; overflow:hidden; max-width:960px; width:92vw; box-shadow: var(--shadow);">
    <?php
      if (has_post_thumbnail()) { the_post_thumbnail('full'); }
      else { echo '<img src="https://picsum.photos/1280/800?grayscale" alt="Karma frame">'; }
    ?>
  </div>
</section>
<?php get_footer(); ?>
