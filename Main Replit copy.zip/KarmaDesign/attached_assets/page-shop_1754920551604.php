
<?php
/* Template Name: Shop Highlights */
get_header();
?>
<div class="container">
  <h2 style="text-transform:uppercase;letter-spacing:.06em;">Shop</h2>

  <h3>Best Sellers</h3>
  <div class="grid grid-4">
    <?php
      $best = new WP_Query([
        'post_type'=>'product',
        'posts_per_page'=>8,
        'meta_key'=>'total_sales',
        'orderby'=>'meta_value_num',
        'order'=>'DESC'
      ]);
      while($best->have_posts()){ $best->the_post(); wc_get_template_part('content','product'); }
      wp_reset_postdata();
    ?>
  </div>

  <h3 style="margin-top:24px;">Featured</h3>
  <div class="grid grid-4">
    <?php
      $feat = new WP_Query([
        'post_type'=>'product',
        'posts_per_page'=>8,
        'tax_query'=>[ [ 'taxonomy'=>'product_visibility', 'field'=>'name', 'terms'=>'featured' ] ]
      ]);
      while($feat->have_posts()){ $feat->the_post(); wc_get_template_part('content','product'); }
      wp_reset_postdata();
    ?>
  </div>

  <h3 style="margin-top:24px;">All Products</h3>
  <form method="get" class="card" style="padding:12px; margin-bottom:12px; display:grid; gap:12px; grid-template-columns: 1fr 1fr 1fr 1fr;">
    <select class="input" name="cat">
      <option value="">All categories</option>
      <?php
        $terms = get_terms(['taxonomy'=>'product_cat','hide_empty'=>true]);
        foreach($terms as $t){
          $sel = selected(isset($_GET['cat']) ? $_GET['cat'] : '', $t->slug, false);
          echo "<option value='{$t->slug}' {$sel}>{$t->name}</option>";
        }
      ?>
    </select>
    <select class="input" name="avail">
      <option value="">Any availability</option>
      <option value="in" <?php selected(isset($_GET['avail']) && $_GET['avail']=='in'); ?>>Available</option>
      <option value="out" <?php selected(isset($_GET['avail']) && $_GET['avail']=='out'); ?>>Sold Out</option>
    </select>
    <select class="input" name="orderby">
      <option value="">Sort by latest</option>
      <option value="sales" <?php selected(isset($_GET['orderby']) && $_GET['orderby']=='sales'); ?>>Best sellers</option>
      <option value="price" <?php selected(isset($_GET['orderby']) && $_GET['orderby']=='price'); ?>>Price (low to high)</option>
      <option value="price-desc" <?php selected(isset($_GET['orderby']) && $_GET['orderby']=='price-desc'); ?>>Price (high to low)</option>
    </select>
    <button class="btn" type="submit">Apply</button>
  </form>

  <div class="grid grid-4">
    <?php
      $args = ['post_type'=>'product', 'posts_per_page'=>12, 'paged'=>max(1, get_query_var('paged'))];
      if(!empty($_GET['cat'])){
        $args['tax_query'] = [[ 'taxonomy'=>'product_cat', 'field'=>'slug', 'terms'=>sanitize_text_field($_GET['cat']) ]];
      }
      if(!empty($_GET['avail'])){
        $args['meta_query'] = [[ 'key'=>'_stock_status', 'value'=> $_GET['avail']=='in' ? 'instock' : 'outofstock' ]];
      }
      if(!empty($_GET['orderby'])){
        if($_GET['orderby']=='sales'){ $args['meta_key']='total_sales'; $args['orderby']='meta_value_num'; $args['order']='DESC'; }
        if($_GET['orderby']=='price'){ $args['meta_key']='_price'; $args['orderby']='meta_value_num'; $args['order']='ASC'; }
        if($_GET['orderby']=='price-desc'){ $args['meta_key']='_price'; $args['orderby']='meta_value_num'; $args['order']='DESC'; }
      }
      $loop = new WP_Query($args);
      if($loop->have_posts()){
        while($loop->have_posts()){ $loop->the_post(); wc_get_template_part('content','product'); }
        wp_reset_postdata();
      } else {
        echo '<p>No products found.</p>';
      }
    ?>
  </div>
</div>
<?php get_footer(); ?>
