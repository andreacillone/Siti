
<?php get_header(); ?>
<div class="container">
  <h2>Search results</h2>
  <?php if(have_posts()): ?>
    <div class="grid grid-4">
      <?php while(have_posts()): the_post(); global $product; ?>
        <a class="card product-card" href="<?php the_permalink(); ?>">
          <div class="thumb"><?php echo woocommerce_get_product_thumbnail('large'); ?></div>
          <div class="meta">
            <div class="name"><?php the_title(); ?></div>
            <?php if($product && !$product->is_in_stock()): ?>
              <span class="badge soldout">Sold Out</span>
            <?php else: ?>
              <span class="badge available">Available</span>
            <?php endif; ?>
          </div>
        </a>
      <?php endwhile; ?>
    </div>
  <?php else: ?>
    <p>No results found. Please check your search and try again.</p>
  <?php endif; ?>
</div>
<?php get_footer(); ?>
