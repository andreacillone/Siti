
<?php
/**
 * Theme bootstrap
 */
add_action('after_setup_theme', function(){
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('woocommerce');
  add_theme_support('custom-logo', ['height'=>48,'width'=>160,'flex-height'=>true,'flex-width'=>true]);
  register_nav_menus([
    'primary' => __('Primary Menu','karma'),
  ]);
});

add_action('wp_enqueue_scripts', function(){
  wp_enqueue_style('karma-style', get_stylesheet_uri(), [], '1.0.0');
  wp_enqueue_script('karma-js', get_template_directory_uri().'/assets/js/main.js', ['jquery'], '1.0.0', true);
  wp_localize_script('karma-js', 'KARMA', [
    'ajax_url' => admin_url('admin-ajax.php'),
    'home_url' => home_url('/'),
  ]);
});

/** Product meta boxes (Frame, Dimensions, Year, Number, Video links) */
add_action('add_meta_boxes', function(){
  add_meta_box('karma_product_meta', __('Karma Product Details','karma'), 'karma_product_meta_cb', 'product', 'normal', 'default');
});
function karma_product_meta_cb($post){
  $vals = [
    'frame' => get_post_meta($post->ID, '_karma_frame', true),
    'dimensions' => get_post_meta($post->ID, '_karma_dimensions', true),
    'year' => get_post_meta($post->ID, '_karma_year', true),
    'number' => get_post_meta($post->ID, '_karma_number', true),
    'ig' => get_post_meta($post->ID, '_karma_video_ig', true),
    'tt' => get_post_meta($post->ID, '_karma_video_tt', true),
    'fb' => get_post_meta($post->ID, '_karma_video_fb', true),
  ];
  wp_nonce_field('karma_meta_nonce','karma_meta_nonce');
  ?>
  <style>.karma-fields input{width:100%;padding:8px;margin:6px 0;}</style>
  <div class="karma-fields">
    <p><label>Frame Used</label><br><input name="karma_frame" value="<?php echo esc_attr($vals['frame']);?>"></p>
    <p><label>Total Dimensions</label><br><input name="karma_dimensions" value="<?php echo esc_attr($vals['dimensions']);?>"></p>
    <p><label>Creation Year</label><br><input name="karma_year" value="<?php echo esc_attr($vals['year']);?>"></p>
    <p><label>Number (#)</label><br><input name="karma_number" value="<?php echo esc_attr($vals['number']);?>"></p>
    <p><label>Video Link – Instagram</label><br><input name="karma_video_ig" value="<?php echo esc_attr($vals['ig']);?>"></p>
    <p><label>Video Link – TikTok</label><br><input name="karma_video_tt" value="<?php echo esc_attr($vals['tt']);?>"></p>
    <p><label>Video Link – Facebook</label><br><input name="karma_video_fb" value="<?php echo esc_attr($vals['fb']);?>"></p>
    <p><em>Tip: use SKU as your ID Code (e.g., KAR25001).</em></p>
  </div>
  <?php
}
add_action('save_post', function($post_id){
  if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
  if(!isset($_POST['karma_meta_nonce']) || !wp_verify_nonce($_POST['karma_meta_nonce'],'karma_meta_nonce')) return;
  $fields = [
    '_karma_frame' => 'karma_frame',
    '_karma_dimensions' => 'karma_dimensions',
    '_karma_year' => 'karma_year',
    '_karma_number' => 'karma_number',
    '_karma_video_ig' => 'karma_video_ig',
    '_karma_video_tt' => 'karma_video_tt',
    '_karma_video_fb' => 'karma_video_fb',
  ];
  foreach($fields as $meta => $key){
    if(isset($_POST[$key])) update_post_meta($post_id, $meta, sanitize_text_field($_POST[$key]));
  }
});

/** Include SKU and custom meta in search */
add_action('pre_get_posts', function($q){
  if(is_admin() || !$q->is_main_query()) return;
  if(is_search()){
    $s = $q->get('s');
    $meta_query = ['relation' => 'OR'];
    // SKU search
    $meta_query[] = ['key' => '_sku', 'value' => $s, 'compare' => 'LIKE'];
    // Number
    $meta_query[] = ['key' => '_karma_number', 'value' => $s, 'compare' => 'LIKE'];
    $q->set('post_type', ['product']);
    $q->set('meta_query', $meta_query);
  }
});

/** Short helper to fetch product meta safely */
function karma_meta($post_id, $key, $default=''){
  $v = get_post_meta($post_id, $key, true);
  return $v ? esc_html($v) : $default;
}


/** WooCommerce: add profile image upload on account page */
add_action('woocommerce_edit_account_form', function(){
  ?>
  <p class="form-row">
    <label for="account_avatar"><?php _e('Profile image','karma'); ?></label>
    <input type="file" name="account_avatar" id="account_avatar" accept="image/*">
  </p>
  <?php
});
add_action('woocommerce_save_account_details', function($user_id){
  if(!empty($_FILES['account_avatar']['name'])){
    require_once(ABSPATH.'wp-admin/includes/file.php');
    $uploaded = media_handle_upload('account_avatar', 0);
    if(!is_wp_error($uploaded)){
      update_user_meta($user_id, '_karma_avatar_id', $uploaded);
    }
  }
});
add_filter('get_avatar', function($avatar, $id_or_email, $size, $default, $alt){
  $user = false;
  if (is_numeric($id_or_email)) { $user = get_user_by('id', (int)$id_or_email); }
  elseif (is_object($id_or_email) && !empty($id_or_email->user_id)) { $user = get_user_by('id', (int)$id_or_email->user_id); }
  elseif (is_string($id_or_email)) { $user = get_user_by('email', $id_or_email); }
  if($user){
    $att_id = get_user_meta($user->ID, '_karma_avatar_id', true);
    if($att_id){
      $src = wp_get_attachment_image_url($att_id, [$size,$size]);
      if($src){
        $avatar = '<img alt="'.esc_attr($alt).'" src="'.esc_url($src).'" class="avatar avatar-'.$size.' photo" height="'.$size.'" width="'.$size.'" />';
      }
    }
  }
  return $avatar;
}, 10, 5);

require get_template_directory().'/inc/customizer.php';
