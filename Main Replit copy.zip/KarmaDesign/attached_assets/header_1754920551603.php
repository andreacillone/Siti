
<?php
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class('site theme-dark'); ?>>
<header class="header">
  <div class="header-inner container">
    <?php if (function_exists("the_custom_logo") && has_custom_logo()): ?>
      <div class="site-logo"><?php the_custom_logo(); ?></div>
    <?php else: ?>
      <div class="logo"><a href="<?php echo esc_url(home_url('/')); ?>">Karma</a></div>
    <?php endif; ?>
    <nav class="nav">
      <?php wp_nav_menu(['theme_location'=>'primary','container'=>false,'menu_class'=>'menu','fallback_cb'=>function(){ ?>
        <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
        <a href="<?php echo esc_url(home_url('/gallery/')); ?>">Gallery</a>
        <a href="<?php echo esc_url(home_url('/support/')); ?>">Support</a>
        <a href="#" id="open-search">Search</a>
      <?php }]); ?>
    </nav>
    <div class="tools">
      <button class="btn" id="theme-toggle" aria-label="Toggle theme">🌓</button>
      <button class="btn" id="open-locale" aria-label="Language/Region">🌐</button>
      <?php if (function_exists("wc_get_page_permalink")): ?>
      <a class="btn" href="<?php echo esc_url(wc_get_page_permalink("myaccount")); ?>" aria-label="Account">👤</a>
      <a class="btn" href="<?php echo esc_url(wc_get_cart_url()); ?>" aria-label="Cart">🛒</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<div class="site-content">
<?php get_template_part('parts/search-modal'); ?>
<?php get_template_part('parts/lang-currency-modal'); ?>
