import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { SiInstagram, SiTiktok, SiFacebook } from "react-icons/si";
import { ArrowLeft, ArrowRight, ChevronDown } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import type { Product } from "@shared/schema";

export default function ProductPage() {
  const [, params] = useRoute("/product/:id");
  const [, setLocation] = useLocation();
  const [mainImage, setMainImage] = useState("");
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});

  const { data: product, isLoading } = useQuery<Product>({
    queryKey: ["/api/products", params?.id],
    enabled: !!params?.id,
  });

  const { data: allProducts = [] } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  // Set main image when product loads
  useState(() => {
    if (product && !mainImage) {
      setMainImage(product.mainImage);
    }
  });

  const currentIndex = allProducts.findIndex(p => p.id === params?.id);
  const nextProduct = allProducts[currentIndex + 1] || allProducts[0];

  const toggleSection = (sectionName: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionName]: !prev[sectionName]
    }));
  };

  const handleImageChange = (newImage: string) => {
    setMainImage(newImage);
  };

  const goToNextProduct = () => {
    if (nextProduct) {
      setLocation(`/product/${nextProduct.id}`);
      setMainImage(nextProduct.mainImage);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 pt-24 pb-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <Skeleton className="aspect-square w-full rounded-3xl" />
              <div className="space-y-6">
                <Skeleton className="h-12 w-48" />
                <Skeleton className="h-6 w-16" />
                <div className="space-y-4">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full rounded-2xl" />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 pt-24 pb-16 flex items-center justify-center">
          <div className="text-center">
            <h1 className="font-akira font-bold text-2xl mb-4">Product Not Found</h1>
            <Button onClick={() => setLocation("/gallery")}>Back to Gallery</Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const images = [
    { src: product.frontImage || product.mainImage, alt: "Front view" },
    { src: product.backImage || product.mainImage, alt: "Back view" },
    { src: product.detailImage || product.mainImage, alt: "Detail view" },
  ].filter(img => img.src);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Navigation Buttons */}
          <div className="flex justify-between mb-8">
            <Button
              onClick={() => setLocation("/gallery")}
              variant="outline"
              className="flex items-center space-x-2 px-6 py-3 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-karma-violet hover:text-white transition-all duration-200 glow-hover"
            >
              <ArrowLeft className="h-4 w-4" />
              <span className="font-akira font-bold text-sm">BACK TO GALLERY</span>
            </Button>
            <Button
              onClick={goToNextProduct}
              variant="outline"
              className="flex items-center space-x-2 px-6 py-3 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-karma-violet hover:text-white transition-all duration-200 glow-hover"
            >
              <span className="font-akira font-bold text-sm">NEXT PRODUCT</span>
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Left Side - Image Gallery */}
            <div className="slide-in">
              <div className="relative">
                {/* Main Product Image */}
                <div className="aspect-square bg-slate-100 dark:bg-slate-800 rounded-3xl overflow-hidden mb-4">
                  <img
                    src={mainImage || product.mainImage}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                
                {/* Image Thumbnails */}
                <div className="flex space-x-4">
                  {images.map((image, index) => (
                    <img
                      key={index}
                      src={image.src}
                      alt={image.alt}
                      onClick={() => handleImageChange(image.src)}
                      className={`w-20 h-20 object-cover rounded-xl cursor-pointer border-2 transition-colors ${
                        mainImage === image.src
                          ? "border-karma-violet"
                          : "border-transparent hover:border-karma-violet"
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
            
            {/* Right Side - Product Info */}
            <div className="slide-in">
              <h1 className="font-akira font-black text-4xl md:text-5xl text-karma-violet mb-4">
                {product.name}
              </h1>
              <p className="text-lg text-slate-600 dark:text-slate-400 mb-8">
                {product.year}
              </p>
              
              {/* Expandable Sections */}
              <div className="space-y-4">
                {/* Frame Used */}
                <Collapsible
                  open={expandedSections.frame}
                  onOpenChange={() => toggleSection("frame")}
                >
                  <div className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-lg">
                    <CollapsibleTrigger asChild>
                      <Button
                        variant="ghost"
                        className="w-full flex items-center justify-between p-6 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
                      >
                        <span className="font-akira font-bold text-lg">FRAME USED</span>
                        <ChevronDown
                          className={`h-5 w-5 transition-transform ${
                            expandedSections.frame ? "rotate-180" : ""
                          }`}
                        />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="px-6 pb-6">
                      <p className="text-slate-600 dark:text-slate-400">
                        {product.frameUsed}
                      </p>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
                
                {/* Total Dimensions */}
                <Collapsible
                  open={expandedSections.dimensions}
                  onOpenChange={() => toggleSection("dimensions")}
                >
                  <div className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-lg">
                    <CollapsibleTrigger asChild>
                      <Button
                        variant="ghost"
                        className="w-full flex items-center justify-between p-6 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
                      >
                        <span className="font-akira font-bold text-lg">TOTAL DIMENSIONS</span>
                        <ChevronDown
                          className={`h-5 w-5 transition-transform ${
                            expandedSections.dimensions ? "rotate-180" : ""
                          }`}
                        />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="px-6 pb-6">
                      <p className="text-slate-600 dark:text-slate-400">
                        {product.dimensions}
                      </p>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
                
                {/* ID Code */}
                <Collapsible
                  open={expandedSections.id}
                  onOpenChange={() => toggleSection("id")}
                >
                  <div className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-lg">
                    <CollapsibleTrigger asChild>
                      <Button
                        variant="ghost"
                        className="w-full flex items-center justify-between p-6 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
                      >
                        <span className="font-akira font-bold text-lg">ID CODE</span>
                        <ChevronDown
                          className={`h-5 w-5 transition-transform ${
                            expandedSections.id ? "rotate-180" : ""
                          }`}
                        />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="px-6 pb-6">
                      <p className="text-slate-600 dark:text-slate-400">
                        {product.idCode}
                      </p>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
                
                {/* Video Links */}
                <Collapsible
                  open={expandedSections.videos}
                  onOpenChange={() => toggleSection("videos")}
                >
                  <div className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-lg">
                    <CollapsibleTrigger asChild>
                      <Button
                        variant="ghost"
                        className="w-full flex items-center justify-between p-6 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
                      >
                        <span className="font-akira font-bold text-lg">VIDEO LINKS</span>
                        <ChevronDown
                          className={`h-5 w-5 transition-transform ${
                            expandedSections.videos ? "rotate-180" : ""
                          }`}
                        />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="px-6 pb-6">
                      <div className="flex space-x-4">
                        {product.instagramLink && (
                          <Button
                            variant="ghost"
                            size="icon"
                            asChild
                            className="text-slate-600 dark:text-slate-400 hover:text-karma-violet transition-colors duration-200"
                          >
                            <a href={product.instagramLink} target="_blank" rel="noopener noreferrer">
                              <SiInstagram className="h-6 w-6" />
                            </a>
                          </Button>
                        )}
                        {product.tiktokLink && (
                          <Button
                            variant="ghost"
                            size="icon"
                            asChild
                            className="text-slate-600 dark:text-slate-400 hover:text-karma-violet transition-colors duration-200"
                          >
                            <a href={product.tiktokLink} target="_blank" rel="noopener noreferrer">
                              <SiTiktok className="h-6 w-6" />
                            </a>
                          </Button>
                        )}
                        {product.facebookLink && (
                          <Button
                            variant="ghost"
                            size="icon"
                            asChild
                            className="text-slate-600 dark:text-slate-400 hover:text-karma-violet transition-colors duration-200"
                          >
                            <a href={product.facebookLink} target="_blank" rel="noopener noreferrer">
                              <SiFacebook className="h-6 w-6" />
                            </a>
                          </Button>
                        )}
                      </div>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
