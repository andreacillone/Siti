import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product } from "@shared/schema";

export default function Gallery() {
  const [, setLocation] = useLocation();
  const [displayedCount, setDisplayedCount] = useState(8);
  const [statusFilter, setStatusFilter] = useState<'all' | 'available' | 'sold'>('all');

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const handleProductClick = (productId: string) => {
    setLocation(`/product/${productId}`);
  };

  // Filter products based on availability
  const filteredProducts = products.filter(product => {
    if (statusFilter === 'available') return product.isAvailable;
    if (statusFilter === 'sold') return !product.isAvailable;
    return true;
  });

  const loadMore = () => {
    setDisplayedCount(prev => Math.min(prev + 4, filteredProducts.length));
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      flexDirection: 'column',
      background: 'var(--bg)',
      color: 'var(--text)'
    }}>
      <Navbar />
      
      <main style={{ flex: 1, paddingTop: '96px', paddingBottom: '64px' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px' }}>
          <div className="slide-in">
            <h1 className="font-akira text-center mb-8 text-karma-violet" style={{
              fontSize: 'clamp(28px, 4vw, 44px)',
              fontWeight: 800,
              letterSpacing: '.06em',
              textTransform: 'uppercase'
            }}>
              GALLERY
            </h1>

            {/* Filter Buttons */}
            <div style={{ display: 'flex', justifyContent: 'center', gap: '12px', marginBottom: '32px' }}>
              <button
                onClick={() => setStatusFilter('all')}
                className={`karma-btn font-akira text-sm px-4 h-10 ${statusFilter === 'all' ? 'active' : ''}`}
                style={{
                  background: statusFilter === 'all' ? 'var(--violet)' : 'var(--bg-soft)',
                  color: statusFilter === 'all' ? 'white' : 'var(--text)',
                  border: statusFilter === 'all' ? 'none' : '1px solid var(--border)'
                }}
              >
                ALL
              </button>
              <button
                onClick={() => setStatusFilter('available')}
                className={`karma-btn font-akira text-sm px-4 h-10 ${statusFilter === 'available' ? 'active' : ''}`}
                style={{
                  background: statusFilter === 'available' ? 'var(--violet)' : 'var(--bg-soft)',
                  color: statusFilter === 'available' ? 'white' : 'var(--text)',
                  border: statusFilter === 'available' ? 'none' : '1px solid var(--border)'
                }}
              >
                AVAILABLE
              </button>
              <button
                onClick={() => setStatusFilter('sold')}
                className={`karma-btn font-akira text-sm px-4 h-10 ${statusFilter === 'sold' ? 'active' : ''}`}
                style={{
                  background: statusFilter === 'sold' ? 'var(--violet)' : 'var(--bg-soft)',
                  color: statusFilter === 'sold' ? 'white' : 'var(--text)',
                  border: statusFilter === 'sold' ? 'none' : '1px solid var(--border)'
                }}
              >
                SOLD OUT
              </button>
            </div>
            
            {/* Product Grid */}
            <div style={{
              display: 'grid',
              gap: '24px',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              marginBottom: '48px'
            }}>
              {isLoading
                ? Array.from({ length: 8 }).map((_, i) => (
                    <div key={i} className="karma-card" style={{ textAlign: 'center' }}>
                      <Skeleton style={{ width: '100%', height: '280px' }} />
                      <div style={{ padding: '10px 14px 16px' }}>
                        <Skeleton style={{ height: '24px', width: '120px', margin: '6px 0' }} />
                        <Skeleton style={{ height: '20px', width: '80px' }} />
                      </div>
                    </div>
                  ))
                : filteredProducts.slice(0, displayedCount).map((product) => (
                    <div
                      key={product.id}
                      onClick={() => handleProductClick(product.id)}
                      className="karma-card cursor-pointer"
                      style={{ textAlign: 'center' }}
                    >
                      <div style={{ overflow: 'hidden' }}>
                        <img
                          src={product.mainImage}
                          alt={product.name}
                          style={{
                            width: '100%',
                            height: '280px',
                            objectFit: 'cover',
                            display: 'block',
                            transition: 'transform .3s ease'
                          }}
                          onMouseOver={(e) => {
                            e.currentTarget.style.transform = 'scale(1.05)';
                          }}
                          onMouseOut={(e) => {
                            e.currentTarget.style.transform = 'scale(1)';
                          }}
                        />
                      </div>
                      <div style={{ padding: '10px 14px 16px' }}>
                        <h3 className="font-akira" style={{
                          fontWeight: 800,
                          letterSpacing: '.06em',
                          textTransform: 'uppercase',
                          margin: '6px 0'
                        }}>
                          {product.name}
                        </h3>
                        <span style={{
                          display: 'inline-block',
                          padding: '6px 10px',
                          borderRadius: '999px',
                          background: 'var(--bg-soft)',
                          border: '1px solid var(--border)',
                          color: product.isAvailable ? '#16a34a' : '#ef4444',
                          borderColor: product.isAvailable ? '#16a34a22' : '#ef444422'
                        }}>
                          {product.isAvailable ? "Available" : "Sold Out"}
                        </span>
                      </div>
                    </div>
                  ))}
            </div>
            
            {/* Load More Button */}
            {!isLoading && filteredProducts.length > displayedCount && (
              <div style={{ textAlign: 'center' }}>
                <button
                  onClick={loadMore}
                  className="karma-btn font-akira"
                  style={{
                    padding: '14px 24px',
                    background: 'var(--violet)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '999px'
                  }}
                >
                  LOAD MORE
                </button>
              </div>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
