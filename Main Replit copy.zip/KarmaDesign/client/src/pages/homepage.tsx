import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";

export default function Homepage() {
  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      flexDirection: 'column',
      background: 'var(--bg)',
      color: 'var(--text)'
    }}>
      <Navbar />
      
      <main style={{
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: 'calc(100vh - 64px)'
      }}>
        <div style={{
          maxWidth: '960px',
          width: '92vw',
          padding: 0,
          borderRadius: '22px',
          overflow: 'hidden',
          boxShadow: 'var(--shadow)'
        }}>
          <img
            src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=1280&h=800"
            alt="Framed Hot Wheels Datsun Artwork"
            style={{
              width: '100%',
              height: 'auto',
              display: 'block'
            }}
          />
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
