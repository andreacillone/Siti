import { useState } from "react";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { SiInstagram, SiTiktok, SiFacebook } from "react-icons/si";
import { ShoppingBag, ChevronDown } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

export default function Support() {
  const [expandedFAQs, setExpandedFAQs] = useState<Record<string, boolean>>({});

  const toggleFAQ = (faqId: string) => {
    setExpandedFAQs(prev => ({
      ...prev,
      [faqId]: !prev[faqId]
    }));
  };

  const faqs = [
    {
      id: "faq1",
      question: "ARE THESE REAL HOT WHEELS CARS?",
      answer: "Yes, each artwork features an authentic Hot Wheels die-cast car professionally mounted in a premium frame."
    },
    {
      id: "faq2",
      question: "HOW LONG DOES SHIPPING TAKE?",
      answer: "International shipping typically takes 5-15 business days depending on your location."
    },
    {
      id: "faq3",
      question: "CAN I REQUEST CUSTOM CARS?",
      answer: "Each piece is unique and created based on artistic inspiration. We do not accept custom requests."
    },
    {
      id: "faq4",
      question: "WHAT IS YOUR RETURN POLICY?",
      answer: "Due to the unique nature of each piece, all sales are final. Each artwork is one-of-a-kind."
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="slide-in">
            <h1 className="font-akira font-black text-4xl md:text-5xl text-center mb-12 text-karma-violet">
              SUPPORT
            </h1>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Left Column - Contact Us */}
              <div className="bg-white dark:bg-slate-800 rounded-3xl p-8 shadow-lg">
                <h2 className="font-akira font-bold text-2xl mb-6 text-karma-violet">
                  CONTACT US
                </h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="font-akira font-bold text-lg mb-2">EMAIL</h3>
                    <a
                      href="mailto:karmaprojects2@gmail.com"
                      className="text-karma-violet hover:text-karma-purple transition-colors"
                    >
                      karmaprojects2@gmail.com
                    </a>
                  </div>
                  
                  <div>
                    <h3 className="font-akira font-bold text-lg mb-2">SUPPORT HOURS</h3>
                    <p className="text-slate-600 dark:text-slate-400">Monday to Saturday</p>
                    <p className="text-slate-600 dark:text-slate-400">08:00–19:00 (UTC+1)</p>
                  </div>
                  
                  <div>
                    <h3 className="font-akira font-bold text-lg mb-4">SOCIAL</h3>
                    <div className="flex space-x-4">
                      <Button
                        variant="outline"
                        size="icon"
                        asChild
                        className="bg-slate-100 dark:bg-slate-700 hover:bg-karma-violet hover:text-white transition-all duration-200 glow-hover"
                      >
                        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                          <SiInstagram className="h-5 w-5" />
                        </a>
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        asChild
                        className="bg-slate-100 dark:bg-slate-700 hover:bg-karma-violet hover:text-white transition-all duration-200 glow-hover"
                      >
                        <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer">
                          <SiTiktok className="h-5 w-5" />
                        </a>
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        asChild
                        className="bg-slate-100 dark:bg-slate-700 hover:bg-karma-violet hover:text-white transition-all duration-200 glow-hover"
                      >
                        <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
                          <SiFacebook className="h-5 w-5" />
                        </a>
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        asChild
                        className="bg-slate-100 dark:bg-slate-700 hover:bg-karma-violet hover:text-white transition-all duration-200 glow-hover"
                      >
                        <a href="https://vinted.com" target="_blank" rel="noopener noreferrer">
                          <ShoppingBag className="h-5 w-5" />
                        </a>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Right Column - FAQ */}
              <div className="bg-white dark:bg-slate-800 rounded-3xl p-8 shadow-lg">
                <h2 className="font-akira font-bold text-2xl mb-6 text-karma-violet">
                  FREQUENTLY ASKED QUESTIONS
                </h2>
                
                <div className="space-y-4">
                  {faqs.map((faq) => (
                    <Collapsible
                      key={faq.id}
                      open={expandedFAQs[faq.id]}
                      onOpenChange={() => toggleFAQ(faq.id)}
                    >
                      <div className="border-b border-slate-200 dark:border-slate-700 pb-4">
                        <CollapsibleTrigger asChild>
                          <Button
                            variant="ghost"
                            className="w-full flex items-center justify-between text-left p-0 h-auto"
                          >
                            <span className="font-akira font-bold">{faq.question}</span>
                            <ChevronDown
                              className={`h-5 w-5 transition-transform ${
                                expandedFAQs[faq.id] ? "rotate-180" : ""
                              }`}
                            />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-4 text-slate-600 dark:text-slate-400">
                          {faq.answer}
                        </CollapsibleContent>
                      </div>
                    </Collapsible>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
