import { useState } from "react";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trash2, Plus, Minus, CreditCard, ShoppingBag } from "lucide-react";

// Mock cart data
const mockCartItems = [
  {
    id: 1,
    name: "Framed Datsun 240Z",
    price: 89.99,
    quantity: 1,
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
  },
  {
    id: 2,
    name: "Vintage Mustang Collection",
    price: 125.99,
    quantity: 2,
    image: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
  }
];

export default function Cart() {
  const [cartItems, setCartItems] = useState(mockCartItems);
  
  const updateQuantity = (id: number, newQuantity: number) => {
    if (newQuantity === 0) {
      setCartItems(cartItems.filter(item => item.id !== id));
    } else {
      setCartItems(cartItems.map(item => 
        item.id === id ? { ...item, quantity: newQuantity } : item
      ));
    }
  };

  const removeItem = (id: number) => {
    setCartItems(cartItems.filter(item => item.id !== id));
  };

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const shipping = subtotal > 100 ? 0 : 9.99;
  const total = subtotal + shipping;

  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      flexDirection: 'column',
      background: 'var(--bg)',
      color: 'var(--text)'
    }}>
      <Navbar />
      
      <main style={{ flex: 1, paddingTop: '96px', paddingBottom: '64px' }}>
        <div style={{ maxWidth: '800px', margin: '0 auto', padding: '0 24px' }}>
          <h1 className="font-akira text-center mb-12 text-karma-violet" style={{
            fontSize: 'clamp(28px, 4vw, 44px)',
            fontWeight: 800,
            letterSpacing: '.06em',
            textTransform: 'uppercase'
          }}>
            CART
          </h1>

          {cartItems.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '48px 0' }}>
              <ShoppingBag className="mx-auto mb-4 h-12 w-12 text-muted" />
              <h3 className="font-akira text-lg mb-2">YOUR CART IS EMPTY</h3>
              <p style={{ color: 'var(--muted)', marginBottom: '24px' }}>
                Add some items to get started
              </p>
              <Button 
                asChild
                style={{
                  padding: '12px 24px',
                  background: 'var(--violet)',
                  color: 'white',
                  border: 'none',
                  borderRadius: '12px'
                }}
                className="font-akira"
              >
                <a href="/gallery">BROWSE GALLERY</a>
              </Button>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: '24px', alignItems: 'flex-start' }}>
              {/* Cart Items */}
              <div>
                {cartItems.map((item) => (
                  <div key={item.id} className="karma-card" style={{ padding: '16px', marginBottom: '16px' }}>
                    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
                      <img
                        src={item.image}
                        alt={item.name}
                        style={{
                          width: '80px',
                          height: '80px',
                          objectFit: 'cover',
                          borderRadius: '8px',
                          flexShrink: 0
                        }}
                      />
                      
                      <div style={{ flex: 1 }}>
                        <h3 className="font-akira text-sm mb-1">{item.name}</h3>
                        <p style={{ color: 'var(--muted)', fontSize: '14px' }}>
                          ${item.price.toFixed(2)} each
                        </p>
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          style={{
                            width: '32px',
                            height: '32px',
                            borderRadius: '8px',
                            border: '1px solid var(--border)',
                            background: 'var(--bg-soft)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer'
                          }}
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        
                        <span style={{ 
                          width: '40px', 
                          textAlign: 'center',
                          fontWeight: 600
                        }}>
                          {item.quantity}
                        </span>
                        
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          style={{
                            width: '32px',
                            height: '32px',
                            borderRadius: '8px',
                            border: '1px solid var(--border)',
                            background: 'var(--bg-soft)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer'
                          }}
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>

                      <button
                        onClick={() => removeItem(item.id)}
                        style={{
                          padding: '8px',
                          borderRadius: '8px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)',
                          cursor: 'pointer',
                          color: '#ef4444'
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Order Summary */}
              <div className="karma-card" style={{ padding: '24px', position: 'sticky', top: '100px' }}>
                <h3 className="font-akira text-lg mb-6">ORDER SUMMARY</h3>
                
                <div style={{ marginBottom: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span>Subtotal</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span>Shipping</span>
                    <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
                  </div>
                  {shipping === 0 && (
                    <p style={{ fontSize: '12px', color: 'var(--muted)', marginBottom: '8px' }}>
                      Free shipping on orders over $100
                    </p>
                  )}
                  <div style={{ 
                    borderTop: '1px solid var(--border)', 
                    paddingTop: '8px',
                    display: 'flex', 
                    justifyContent: 'space-between',
                    fontWeight: 600,
                    fontSize: '18px'
                  }}>
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>

                <Button
                  style={{
                    width: '100%',
                    padding: '14px',
                    background: 'var(--violet)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '12px',
                    marginBottom: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '8px'
                  }}
                  className="font-akira"
                >
                  <CreditCard className="h-4 w-4" />
                  CHECKOUT WITH STRIPE
                </Button>

                <Button
                  variant="outline"
                  style={{
                    width: '100%',
                    padding: '14px',
                    borderRadius: '12px',
                    border: '1px solid var(--border)',
                    background: 'var(--bg-soft)',
                    marginBottom: '12px'
                  }}
                  className="font-akira text-sm"
                >
                  PAY WITH PAYPAL
                </Button>

                <div style={{ 
                  fontSize: '12px', 
                  color: 'var(--muted)', 
                  textAlign: 'center',
                  marginTop: '12px'
                }}>
                  Secure checkout with SSL encryption
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}