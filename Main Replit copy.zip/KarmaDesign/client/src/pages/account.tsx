import { useState } from "react";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Eye, EyeOff, Mail } from "lucide-react";

export default function Account() {
  const [showPassword, setShowPassword] = useState(false);
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      flexDirection: 'column',
      background: 'var(--bg)',
      color: 'var(--text)'
    }}>
      <Navbar />
      
      <main style={{ flex: 1, paddingTop: '96px', paddingBottom: '64px' }}>
        <div style={{ maxWidth: '480px', margin: '0 auto', padding: '0 24px' }}>
          <h1 className="font-akira text-center mb-12 text-karma-violet" style={{
            fontSize: 'clamp(28px, 4vw, 44px)',
            fontWeight: 800,
            letterSpacing: '.06em',
            textTransform: 'uppercase'
          }}>
            ACCOUNT
          </h1>

          <div className="karma-card" style={{ padding: '24px' }}>
            <Tabs value={isLogin ? "login" : "register"} onValueChange={(value) => setIsLogin(value === "login")}>
              <TabsList style={{ 
                display: 'grid',
                width: '100%',
                gridTemplateColumns: '1fr 1fr',
                background: 'var(--bg-soft)',
                border: '1px solid var(--border)',
                borderRadius: '12px',
                padding: '4px'
              }}>
                <TabsTrigger value="login" className="font-akira text-sm">LOGIN</TabsTrigger>
                <TabsTrigger value="register" className="font-akira text-sm">REGISTER</TabsTrigger>
              </TabsList>

              <TabsContent value="login" style={{ marginTop: '24px' }}>
                <form className="space-y-4">
                  <div>
                    <Label className="font-akira text-sm block mb-2">EMAIL</Label>
                    <Input
                      type="email"
                      placeholder="your@email.com"
                      style={{
                        padding: '12px 14px',
                        borderRadius: '12px',
                        border: '1px solid var(--border)',
                        background: 'var(--bg-soft)'
                      }}
                    />
                  </div>
                  
                  <div>
                    <Label className="font-akira text-sm block mb-2">PASSWORD</Label>
                    <div style={{ position: 'relative' }}>
                      <Input
                        type={showPassword ? "text" : "password"}
                        placeholder="••••••••"
                        style={{
                          padding: '12px 14px',
                          paddingRight: '44px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        style={{
                          position: 'absolute',
                          right: '12px',
                          top: '50%',
                          transform: 'translateY(-50%)',
                          background: 'none',
                          border: 'none',
                          cursor: 'pointer',
                          color: 'var(--muted)'
                        }}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  <Button 
                    type="submit"
                    style={{
                      width: '100%',
                      padding: '12px',
                      background: 'var(--violet)',
                      color: 'white',
                      border: 'none',
                      borderRadius: '12px',
                      marginTop: '24px'
                    }}
                    className="font-akira"
                  >
                    LOGIN
                  </Button>

                  <div style={{ textAlign: 'center', margin: '24px 0', color: 'var(--muted)' }}>
                    OR
                  </div>

                  <Button
                    type="button"
                    variant="outline"
                    style={{
                      width: '100%',
                      padding: '12px',
                      borderRadius: '12px',
                      border: '1px solid var(--border)',
                      background: 'var(--bg-soft)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px'
                    }}
                    className="font-akira text-sm"
                  >
                    <Mail className="h-4 w-4" />
                    CONTINUE WITH GOOGLE
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="register" style={{ marginTop: '24px' }}>
                <form className="space-y-4">
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                    <div>
                      <Label className="font-akira text-sm block mb-2">FIRST NAME</Label>
                      <Input
                        type="text"
                        placeholder="John"
                        style={{
                          padding: '12px 14px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                    </div>
                    <div>
                      <Label className="font-akira text-sm block mb-2">LAST NAME</Label>
                      <Input
                        type="text"
                        placeholder="Doe"
                        style={{
                          padding: '12px 14px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="font-akira text-sm block mb-2">EMAIL</Label>
                    <Input
                      type="email"
                      placeholder="your@email.com"
                      style={{
                        padding: '12px 14px',
                        borderRadius: '12px',
                        border: '1px solid var(--border)',
                        background: 'var(--bg-soft)'
                      }}
                    />
                  </div>
                  
                  <div>
                    <Label className="font-akira text-sm block mb-2">PASSWORD</Label>
                    <div style={{ position: 'relative' }}>
                      <Input
                        type={showPassword ? "text" : "password"}
                        placeholder="••••••••"
                        style={{
                          padding: '12px 14px',
                          paddingRight: '44px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        style={{
                          position: 'absolute',
                          right: '12px',
                          top: '50%',
                          transform: 'translateY(-50%)',
                          background: 'none',
                          border: 'none',
                          cursor: 'pointer',
                          color: 'var(--muted)'
                        }}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  <Button 
                    type="submit"
                    style={{
                      width: '100%',
                      padding: '12px',
                      background: 'var(--violet)',
                      color: 'white',
                      border: 'none',
                      borderRadius: '12px',
                      marginTop: '24px'
                    }}
                    className="font-akira"
                  >
                    CREATE ACCOUNT
                  </Button>

                  <div style={{ textAlign: 'center', margin: '24px 0', color: 'var(--muted)' }}>
                    OR
                  </div>

                  <Button
                    type="button"
                    variant="outline"
                    style={{
                      width: '100%',
                      padding: '12px',
                      borderRadius: '12px',
                      border: '1px solid var(--border)',
                      background: 'var(--bg-soft)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px'
                    }}
                    className="font-akira text-sm"
                  >
                    <Mail className="h-4 w-4" />
                    SIGN UP WITH GOOGLE
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}