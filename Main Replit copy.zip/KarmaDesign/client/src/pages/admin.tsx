import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Package, 
  Users, 
  ShoppingCart, 
  Settings, 
  Plus, 
  Edit, 
  Trash2, 
  Upload,
  Eye,
  EyeOff,
  CheckCircle,
  XCircle,
  Clock
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface AdminProduct {
  id: string;
  name: string;
  price: number;
  isAvailable: boolean;
  stock: number;
  image: string;
  description?: string;
  videoUrl?: string;
}

// Mock data - in real app this would come from API
const mockProducts: AdminProduct[] = [
  { id: "1", name: "DATSUN 240Z", price: 89.99, isAvailable: true, stock: 5, image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
  { id: "2", name: "MUSTANG GT", price: 125.99, isAvailable: false, stock: 0, image: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
];

const mockOrders = [
  { id: "ORD001", customer: "John Doe", total: 89.99, status: "pending", date: "2025-01-11", items: ["DATSUN 240Z"] },
  { id: "ORD002", customer: "Jane Smith", total: 215.98, status: "shipped", date: "2025-01-10", items: ["MUSTANG GT", "DATSUN 240Z"] },
  { id: "ORD003", customer: "Mike Johnson", total: 125.99, status: "delivered", date: "2025-01-09", items: ["MUSTANG GT"] },
];

const mockUsers = [
  { id: "1", email: "john@example.com", name: "John Doe", role: "customer", orders: 3, joined: "2024-12-15" },
  { id: "2", email: "jane@example.com", name: "Jane Smith", role: "customer", orders: 1, joined: "2025-01-01" },
  { id: "3", email: "admin@karma.com", name: "Admin User", role: "admin", orders: 0, joined: "2024-11-01" },
];

export default function Admin() {
  const [activeTab, setActiveTab] = useState("products");
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<AdminProduct | null>(null);

  const [productForm, setProductForm] = useState({
    name: "",
    price: "",
    description: "",
    isAvailable: true,
    stock: "",
    image: "",
    videoUrl: ""
  });

  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In real app, make API call to create/update product
    console.log("Product submitted:", productForm);
    setShowProductForm(false);
    setProductForm({ name: "", price: "", description: "", isAvailable: true, stock: "", image: "", videoUrl: "" });
  };

  const handleOrderStatusChange = (orderId: string, newStatus: string) => {
    // In real app, make API call to update order status
    console.log("Order", orderId, "status changed to", newStatus);
  };

  const handleDeleteProduct = (productId: string) => {
    // In real app, make API call to delete product
    console.log("Delete product:", productId);
  };

  const getStatusBadge = (status: string) => {
    const colors: { [key: string]: string } = {
      pending: "bg-yellow-500",
      shipped: "bg-blue-500", 
      delivered: "bg-green-500",
      cancelled: "bg-red-500"
    };
    return colors[status] || "bg-gray-500";
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      flexDirection: 'column',
      background: 'var(--bg)',
      color: 'var(--text)'
    }}>
      <Navbar />
      
      <main style={{ flex: 1, paddingTop: '96px', paddingBottom: '64px' }}>
        <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '0 24px' }}>
          <h1 className="font-akira text-center mb-12 text-karma-violet" style={{
            fontSize: 'clamp(28px, 4vw, 44px)',
            fontWeight: 800,
            letterSpacing: '.06em',
            textTransform: 'uppercase'
          }}>
            ADMIN PANEL
          </h1>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList style={{ 
              display: 'grid',
              width: '100%',
              gridTemplateColumns: '1fr 1fr 1fr 1fr',
              background: 'var(--bg-soft)',
              border: '1px solid var(--border)',
              borderRadius: '12px',
              padding: '4px',
              marginBottom: '32px'
            }}>
              <TabsTrigger value="products" className="font-akira text-sm">
                <Package className="h-4 w-4 mr-2" />
                PRODUCTS
              </TabsTrigger>
              <TabsTrigger value="orders" className="font-akira text-sm">
                <ShoppingCart className="h-4 w-4 mr-2" />
                ORDERS
              </TabsTrigger>
              <TabsTrigger value="users" className="font-akira text-sm">
                <Users className="h-4 w-4 mr-2" />
                USERS
              </TabsTrigger>
              <TabsTrigger value="settings" className="font-akira text-sm">
                <Settings className="h-4 w-4 mr-2" />
                SETTINGS
              </TabsTrigger>
            </TabsList>

            {/* Products Tab */}
            <TabsContent value="products">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                <h2 className="font-akira text-xl">Product Management</h2>
                <Button
                  onClick={() => setShowProductForm(true)}
                  style={{
                    background: 'var(--violet)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '12px',
                    padding: '12px 20px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px'
                  }}
                  className="font-akira"
                >
                  <Plus className="h-4 w-4" />
                  ADD PRODUCT
                </Button>
              </div>

              {showProductForm && (
                <div className="karma-card" style={{ padding: '24px', marginBottom: '24px' }}>
                  <h3 className="font-akira text-lg mb-6">
                    {editingProduct ? 'EDIT PRODUCT' : 'NEW PRODUCT'}
                  </h3>
                  
                  <form onSubmit={handleProductSubmit}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                      <div>
                        <Label className="font-akira text-sm block mb-2">PRODUCT NAME</Label>
                        <Input
                          value={productForm.name}
                          onChange={(e) => setProductForm({...productForm, name: e.target.value})}
                          placeholder="Hot Wheels Datsun 240Z"
                          style={{
                            padding: '12px 14px',
                            borderRadius: '12px',
                            border: '1px solid var(--border)',
                            background: 'var(--bg-soft)'
                          }}
                        />
                      </div>
                      <div>
                        <Label className="font-akira text-sm block mb-2">PRICE ($)</Label>
                        <Input
                          type="number"
                          value={productForm.price}
                          onChange={(e) => setProductForm({...productForm, price: e.target.value})}
                          placeholder="89.99"
                          style={{
                            padding: '12px 14px',
                            borderRadius: '12px',
                            border: '1px solid var(--border)',
                            background: 'var(--bg-soft)'
                          }}
                        />
                      </div>
                    </div>

                    <div style={{ marginBottom: '16px' }}>
                      <Label className="font-akira text-sm block mb-2">DESCRIPTION</Label>
                      <Textarea
                        value={productForm.description}
                        onChange={(e) => setProductForm({...productForm, description: e.target.value})}
                        placeholder="Framed Hot Wheels die-cast car with authentic details..."
                        rows={3}
                        style={{
                          padding: '12px 14px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)',
                          resize: 'vertical'
                        }}
                      />
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                      <div>
                        <Label className="font-akira text-sm block mb-2">IMAGE URL</Label>
                        <Input
                          value={productForm.image}
                          onChange={(e) => setProductForm({...productForm, image: e.target.value})}
                          placeholder="https://images.unsplash.com/..."
                          style={{
                            padding: '12px 14px',
                            borderRadius: '12px',
                            border: '1px solid var(--border)',
                            background: 'var(--bg-soft)'
                          }}
                        />
                      </div>
                      <div>
                        <Label className="font-akira text-sm block mb-2">VIDEO URL (Optional)</Label>
                        <Input
                          value={productForm.videoUrl}
                          onChange={(e) => setProductForm({...productForm, videoUrl: e.target.value})}
                          placeholder="https://youtube.com/watch?v=..."
                          style={{
                            padding: '12px 14px',
                            borderRadius: '12px',
                            border: '1px solid var(--border)',
                            background: 'var(--bg-soft)'
                          }}
                        />
                      </div>
                    </div>

                    <div style={{ display: 'flex', gap: '16px', alignItems: 'center', marginBottom: '24px' }}>
                      <div>
                        <Label className="font-akira text-sm block mb-2">STOCK</Label>
                        <Input
                          type="number"
                          value={productForm.stock}
                          onChange={(e) => setProductForm({...productForm, stock: e.target.value})}
                          placeholder="10"
                          style={{
                            padding: '12px 14px',
                            borderRadius: '12px',
                            border: '1px solid var(--border)',
                            background: 'var(--bg-soft)',
                            width: '120px'
                          }}
                        />
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '28px' }}>
                        <input
                          type="checkbox"
                          id="available"
                          checked={productForm.isAvailable}
                          onChange={(e) => setProductForm({...productForm, isAvailable: e.target.checked})}
                          style={{ marginRight: '4px' }}
                        />
                        <Label htmlFor="available" className="font-akira text-sm">
                          AVAILABLE FOR SALE
                        </Label>
                      </div>
                    </div>

                    <div style={{ display: 'flex', gap: '12px' }}>
                      <Button
                        type="submit"
                        style={{
                          background: 'var(--violet)',
                          color: 'white',
                          border: 'none',
                          borderRadius: '12px',
                          padding: '12px 24px'
                        }}
                        className="font-akira"
                      >
                        {editingProduct ? 'UPDATE PRODUCT' : 'CREATE PRODUCT'}
                      </Button>
                      <Button
                        type="button"
                        onClick={() => {
                          setShowProductForm(false);
                          setEditingProduct(null);
                          setProductForm({ name: "", price: "", description: "", isAvailable: true, stock: "", image: "", videoUrl: "" });
                        }}
                        style={{
                          background: 'var(--bg-soft)',
                          color: 'var(--text)',
                          border: '1px solid var(--border)',
                          borderRadius: '12px',
                          padding: '12px 24px'
                        }}
                        className="font-akira"
                      >
                        CANCEL
                      </Button>
                    </div>
                  </form>
                </div>
              )}

              {/* Products List */}
              <div style={{ display: 'grid', gap: '16px' }}>
                {mockProducts.map((product) => (
                  <div key={product.id} className="karma-card" style={{ padding: '20px' }}>
                    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
                      <img
                        src={product.image}
                        alt={product.name}
                        style={{
                          width: '80px',
                          height: '80px',
                          objectFit: 'cover',
                          borderRadius: '8px'
                        }}
                      />
                      
                      <div style={{ flex: 1 }}>
                        <h3 className="font-akira text-lg mb-1">{product.name}</h3>
                        <p style={{ color: 'var(--muted)', marginBottom: '8px' }}>
                          ${product.price} • Stock: {product.stock}
                        </p>
                        <Badge 
                          style={{
                            background: product.isAvailable ? '#10b981' : '#ef4444',
                            color: 'white',
                            fontSize: '12px'
                          }}
                        >
                          {product.isAvailable ? 'AVAILABLE' : 'SOLD OUT'}
                        </Badge>
                      </div>

                      <div style={{ display: 'flex', gap: '8px' }}>
                        <Button
                          onClick={() => {
                            setEditingProduct(product);
                            setProductForm({
                              name: product.name,
                              price: product.price.toString(),
                              description: product.description || "",
                              isAvailable: product.isAvailable,
                              stock: product.stock.toString(),
                              image: product.image,
                              videoUrl: product.videoUrl || ""
                            });
                            setShowProductForm(true);
                          }}
                          style={{
                            padding: '8px',
                            borderRadius: '8px',
                            border: '1px solid var(--border)',
                            background: 'var(--bg-soft)'
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          onClick={() => handleDeleteProduct(product.id)}
                          style={{
                            padding: '8px',
                            borderRadius: '8px',
                            border: '1px solid #ef4444',
                            background: 'rgba(239, 68, 68, 0.1)',
                            color: '#ef4444'
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                        <Button
                          style={{
                            padding: '8px',
                            borderRadius: '8px',
                            border: '1px solid var(--border)',
                            background: 'var(--bg-soft)'
                          }}
                        >
                          {product.isAvailable ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Orders Tab */}
            <TabsContent value="orders">
              <div style={{ marginBottom: '24px' }}>
                <h2 className="font-akira text-xl mb-4">Order Management</h2>
                <div style={{ display: 'flex', gap: '12px', marginBottom: '16px' }}>
                  <Badge style={{ background: 'var(--bg-soft)', color: 'var(--text)', border: '1px solid var(--border)' }}>
                    Total Orders: {mockOrders.length}
                  </Badge>
                  <Badge style={{ background: '#fef3c7', color: '#d97706' }}>
                    Pending: {mockOrders.filter(o => o.status === 'pending').length}
                  </Badge>
                  <Badge style={{ background: '#dbeafe', color: '#2563eb' }}>
                    Shipped: {mockOrders.filter(o => o.status === 'shipped').length}
                  </Badge>
                  <Badge style={{ background: '#d1fae5', color: '#10b981' }}>
                    Delivered: {mockOrders.filter(o => o.status === 'delivered').length}
                  </Badge>
                </div>
              </div>

              <div style={{ display: 'grid', gap: '16px' }}>
                {mockOrders.map((order) => (
                  <div key={order.id} className="karma-card" style={{ padding: '20px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                      <div>
                        <h3 className="font-akira text-lg mb-1">{order.id}</h3>
                        <p style={{ color: 'var(--muted)', fontSize: '14px' }}>
                          {order.customer} • {order.date}
                        </p>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <div className="font-akira text-lg mb-1">${order.total}</div>
                        <Badge 
                          style={{
                            background: getStatusBadge(order.status),
                            color: 'white',
                            textTransform: 'uppercase'
                          }}
                        >
                          {order.status}
                        </Badge>
                      </div>
                    </div>
                    
                    <div style={{ marginBottom: '16px' }}>
                      <p style={{ color: 'var(--muted)', fontSize: '14px', marginBottom: '8px' }}>
                        Items: {order.items.join(', ')}
                      </p>
                    </div>

                    <div style={{ display: 'flex', gap: '8px' }}>
                      <select
                        value={order.status}
                        onChange={(e) => handleOrderStatusChange(order.id, e.target.value)}
                        style={{
                          padding: '6px 12px',
                          borderRadius: '8px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)',
                          color: 'var(--text)',
                          fontSize: '12px'
                        }}
                      >
                        <option value="pending">Pending</option>
                        <option value="shipped">Shipped</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                      <Button
                        style={{
                          padding: '6px 12px',
                          fontSize: '12px',
                          borderRadius: '8px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                        className="font-akira"
                      >
                        VIEW DETAILS
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Users Tab */}
            <TabsContent value="users">
              <h2 className="font-akira text-xl mb-6">User Management</h2>
              
              <div style={{ display: 'grid', gap: '16px' }}>
                {mockUsers.map((user) => (
                  <div key={user.id} className="karma-card" style={{ padding: '20px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <h3 className="font-akira text-lg mb-1">{user.name}</h3>
                        <p style={{ color: 'var(--muted)', fontSize: '14px', marginBottom: '8px' }}>
                          {user.email}
                        </p>
                        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                          <Badge 
                            style={{
                              background: user.role === 'admin' ? 'var(--violet)' : 'var(--bg-soft)',
                              color: user.role === 'admin' ? 'white' : 'var(--text)',
                              border: user.role === 'admin' ? 'none' : '1px solid var(--border)'
                            }}
                          >
                            {user.role.toUpperCase()}
                          </Badge>
                          <span style={{ fontSize: '14px', color: 'var(--muted)' }}>
                            {user.orders} orders • Joined {user.joined}
                          </span>
                        </div>
                      </div>
                      
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <Button
                          style={{
                            padding: '8px 16px',
                            fontSize: '12px',
                            borderRadius: '8px',
                            border: '1px solid var(--border)',
                            background: 'var(--bg-soft)'
                          }}
                          className="font-akira"
                        >
                          EDIT
                        </Button>
                        {user.role !== 'admin' && (
                          <Button
                            style={{
                              padding: '8px 16px',
                              fontSize: '12px',
                              borderRadius: '8px',
                              border: '1px solid #ef4444',
                              background: 'rgba(239, 68, 68, 0.1)',
                              color: '#ef4444'
                            }}
                            className="font-akira"
                          >
                            BLOCK
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings">
              <h2 className="font-akira text-xl mb-6">Site Settings</h2>
              
              <div style={{ display: 'grid', gap: '24px' }}>
                {/* General Settings */}
                <div className="karma-card" style={{ padding: '24px' }}>
                  <h3 className="font-akira text-lg mb-4">GENERAL SETTINGS</h3>
                  <div style={{ display: 'grid', gap: '16px' }}>
                    <div>
                      <Label className="font-akira text-sm block mb-2">SITE NAME</Label>
                      <Input
                        defaultValue="KARMA"
                        style={{
                          padding: '12px 14px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                    </div>
                    <div>
                      <Label className="font-akira text-sm block mb-2">CONTACT EMAIL</Label>
                      <Input
                        defaultValue="contact@karma.com"
                        style={{
                          padding: '12px 14px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                    </div>
                  </div>
                </div>

                {/* Payment Settings */}
                <div className="karma-card" style={{ padding: '24px' }}>
                  <h3 className="font-akira text-lg mb-4">PAYMENT SETTINGS</h3>
                  <div style={{ display: 'grid', gap: '16px' }}>
                    <div>
                      <Label className="font-akira text-sm block mb-2">STRIPE PUBLISHABLE KEY</Label>
                      <Input
                        type="password"
                        placeholder="pk_test_..."
                        style={{
                          padding: '12px 14px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                    </div>
                    <div>
                      <Label className="font-akira text-sm block mb-2">PAYPAL CLIENT ID</Label>
                      <Input
                        type="password"
                        placeholder="Your PayPal Client ID"
                        style={{
                          padding: '12px 14px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                    </div>
                  </div>
                </div>

                {/* Social Media Settings */}
                <div className="karma-card" style={{ padding: '24px' }}>
                  <h3 className="font-akira text-lg mb-4">SOCIAL MEDIA LINKS</h3>
                  <div style={{ display: 'grid', gap: '16px' }}>
                    <div>
                      <Label className="font-akira text-sm block mb-2">INSTAGRAM</Label>
                      <Input
                        placeholder="https://instagram.com/karma"
                        style={{
                          padding: '12px 14px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                    </div>
                    <div>
                      <Label className="font-akira text-sm block mb-2">TIKTOK</Label>
                      <Input
                        placeholder="https://tiktok.com/@karma"
                        style={{
                          padding: '12px 14px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                    </div>
                    <div>
                      <Label className="font-akira text-sm block mb-2">YOUTUBE SHORTS</Label>
                      <Input
                        placeholder="https://youtube.com/@karma/shorts"
                        style={{
                          padding: '12px 14px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                    </div>
                    <div>
                      <Label className="font-akira text-sm block mb-2">FACEBOOK</Label>
                      <Input
                        placeholder="https://facebook.com/karma"
                        style={{
                          padding: '12px 14px',
                          borderRadius: '12px',
                          border: '1px solid var(--border)',
                          background: 'var(--bg-soft)'
                        }}
                      />
                    </div>
                  </div>
                </div>

                <Button
                  style={{
                    background: 'var(--violet)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '12px',
                    padding: '14px 32px',
                    alignSelf: 'flex-start'
                  }}
                  className="font-akira"
                >
                  SAVE SETTINGS
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}