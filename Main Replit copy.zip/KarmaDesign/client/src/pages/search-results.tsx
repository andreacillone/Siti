import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Search } from "lucide-react";
import type { Product } from "@shared/schema";

export default function SearchResults() {
  const [location, setLocation] = useLocation();
  
  // Parse search parameters from URL
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  const name = searchParams.get('name') || '';
  const idCode = searchParams.get('idCode') || '';
  const number = searchParams.get('number') || '';

  const { data: results = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/search", { name, idCode, number }],
    enabled: !!(name || idCode || number),
  });

  const handleProductClick = (productId: string) => {
    setLocation(`/product/${productId}`);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="slide-in">
            <h1 className="font-akira font-black text-4xl md:text-5xl text-center mb-8 text-karma-violet">
              SEARCH RESULTS
            </h1>
            
            {/* Show search criteria */}
            <div className="text-center mb-8">
              <p className="text-slate-600 dark:text-slate-400">
                Searching for: {name && `Name: "${name}"`} {idCode && `ID: "${idCode}"`} {number && `Number: "${number}"`}
              </p>
            </div>
            
            <div id="searchResultsContent">
              {isLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mb-8">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="bg-white dark:bg-slate-800 rounded-3xl shadow-lg overflow-hidden">
                      <Skeleton className="aspect-square w-full" />
                      <div className="p-6 space-y-2">
                        <Skeleton className="h-6 w-24" />
                        <Skeleton className="h-5 w-16" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : results.length === 0 ? (
                <div className="text-center py-12">
                  <Search className="h-16 w-16 text-slate-400 mb-4 mx-auto" />
                  <h2 className="font-akira font-bold text-2xl mb-4">NO RESULTS FOUND</h2>
                  <p className="text-slate-600 dark:text-slate-400 mb-6">
                    Please check your search and try again.
                  </p>
                  <Button
                    onClick={() => setLocation("/gallery")}
                    className="px-6 py-3 bg-karma-violet hover:bg-karma-purple text-white font-akira font-bold rounded-xl transition-all duration-200 glow-hover"
                  >
                    BACK TO GALLERY
                  </Button>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mb-8">
                    {results.map((product) => (
                      <div
                        key={product.id}
                        onClick={() => handleProductClick(product.id)}
                        className="bg-white dark:bg-slate-800 rounded-3xl shadow-lg overflow-hidden glow-hover cursor-pointer"
                      >
                        <div className="aspect-square overflow-hidden">
                          <img
                            src={product.mainImage}
                            alt={product.name}
                            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                        <div className="p-6">
                          <h3 className="font-akira font-bold text-xl mb-2">
                            {product.name}
                          </h3>
                          <Badge
                            variant={product.isAvailable ? "default" : "destructive"}
                            className={
                              product.isAvailable
                                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                                : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                            }
                          >
                            {product.isAvailable ? "Available" : "Sold Out"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="text-center">
                    <Button
                      onClick={() => setLocation("/gallery")}
                      className="px-6 py-3 bg-karma-violet hover:bg-karma-purple text-white font-akira font-bold rounded-xl transition-all duration-200 glow-hover"
                    >
                      BACK TO GALLERY
                    </Button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
