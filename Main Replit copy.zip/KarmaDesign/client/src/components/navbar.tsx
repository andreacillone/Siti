import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { SearchModal } from "./search-modal";
import { useThemeContext } from "./theme-provider";
import { Moon, Sun, Globe, Menu, X, ShoppingCart, ShoppingBag, Settings } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Navbar() {
  const [location] = useLocation();
  const { theme, toggleTheme } = useThemeContext();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-[8px]" style={{ 
        background: 'color-mix(in srgb, var(--bg) 70%, transparent)',
        borderBottom: '1px solid var(--border)'
      }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between h-16">
            {/* Left Side - Logo + Navigation */}
            <div className="flex items-center space-x-8">
              <Link href="/">
                <button className="font-akira text-2xl text-karma-violet hover:opacity-80 transition-opacity duration-200">
                  KARMA
                </button>
              </Link>
              
              {/* Desktop Navigation Links */}
              <div className="hidden md:flex items-center space-x-6">
                <Link href="/gallery">
                  <button className={`font-akira text-sm transition-colors duration-200 ${
                    location === "/gallery" ? "text-karma-violet" : ""
                  } hover:text-karma-violet`}>
                    GALLERY
                  </button>
                </Link>
                <Link href="/support">
                  <button className={`font-akira text-sm transition-colors duration-200 ${
                    location === "/support" ? "text-karma-violet" : ""
                  } hover:text-karma-violet`}>
                    SUPPORT
                  </button>
                </Link>
                <button
                  onClick={() => setIsSearchOpen(true)}
                  className="font-akira text-sm hover:text-karma-violet transition-colors duration-200"
                >
                  SEARCH
                </button>
              </div>
            </div>

            {/* Right Side Controls */}
            <div className="flex items-center space-x-3">
              {/* Account/Login */}
              <Link href="/account">
                <button className="karma-btn font-akira text-sm px-4 h-10">
                  ACCOUNT
                </button>
              </Link>

              {/* Cart */}
              <Link href="/cart">
                <button className="karma-btn w-10 h-10 rounded-full relative">
                  <ShoppingBag className="h-4 w-4" />
                </button>
              </Link>

              {/* Admin Panel Link (visible for admins) */}
              <Link href="/admin">
                <button className="karma-btn w-10 h-10 rounded-full">
                  <Settings className="h-4 w-4" />
                </button>
              </Link>

              {/* Theme Toggle */}
              <button
                onClick={toggleTheme}
                className="karma-btn w-10 h-10 rounded-full"
                aria-label="Toggle theme"
              >
                {theme === "dark" ? (
                  <Sun className="h-4 w-4" />
                ) : (
                  <Moon className="h-4 w-4" />
                )}
              </button>

              {/* Language Selector */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    className="karma-btn font-akira text-xs px-3 h-10"
                    aria-label="Language/Region"
                  >
                    EN
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-32" style={{
                  background: 'var(--card)',
                  border: '1px solid var(--border)',
                  borderRadius: '12px'
                }}>
                  <DropdownMenuItem>EN - English</DropdownMenuItem>
                  <DropdownMenuItem>IT - Italiano</DropdownMenuItem>
                  <DropdownMenuItem>FR - Français</DropdownMenuItem>
                  <DropdownMenuItem>ES - Español</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden karma-btn w-10 h-10 rounded-full"
              >
                {isMobileMenuOpen ? (
                  <X className="h-4 w-4" />
                ) : (
                  <Menu className="h-4 w-4" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden" style={{ 
            background: 'var(--bg)', 
            borderTop: '1px solid var(--border)' 
          }}>
            <div className="px-6 py-4 space-y-2">
              <Link href="/gallery">
                <button
                  className="block w-full text-left font-akira text-sm hover:text-karma-violet py-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  GALLERY
                </button>
              </Link>
              <Link href="/support">
                <button
                  className="block w-full text-left font-akira text-sm hover:text-karma-violet py-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  SUPPORT
                </button>
              </Link>
              <button
                onClick={() => {
                  setIsSearchOpen(true);
                  setIsMobileMenuOpen(false);
                }}
                className="block w-full text-left font-akira text-sm hover:text-karma-violet py-2"
              >
                SEARCH
              </button>
            </div>
          </div>
        )}
      </nav>

      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </>
  );
}
