import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { X } from "lucide-react";

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const [, setLocation] = useLocation();
  const [carName, setCarName] = useState("");
  const [idCode, setIdCode] = useState("");
  const [number, setNumber] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const params = new URLSearchParams();
    if (carName) params.set("name", carName);
    if (idCode) params.set("idCode", idCode);
    if (number) params.set("number", number);
    
    setLocation(`/search-results?${params.toString()}`);
    onClose();
    
    // Reset form
    setCarName("");
    setIdCode("");
    setNumber("");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent 
        className="fade-in"
        style={{
          maxWidth: '640px',
          width: '92vw',
          background: 'var(--card)',
          border: '1px solid var(--border)',
          borderRadius: '18px',
          padding: '18px'
        }}
      >
        <DialogHeader>
          <DialogTitle className="font-akira text-karma-violet" style={{
            textAlign: 'center',
            marginBottom: '18px',
            fontSize: '24px',
            fontWeight: 800,
            letterSpacing: '.06em',
            textTransform: 'uppercase'
          }}>
            SEARCH
          </DialogTitle>
          <p style={{ 
            textAlign: 'center', 
            color: 'var(--muted)', 
            fontSize: '14px',
            marginBottom: '12px'
          }}>
            Find products by name or number
          </p>
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
            <div>
              <label className="font-akira" style={{ fontSize: '12px', fontWeight: 700, marginBottom: '6px', display: 'block' }}>
                CAR NAME
              </label>
              <input
                type="text"
                value={carName}
                onChange={(e) => setCarName(e.target.value)}
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  borderRadius: '12px',
                  border: '1px solid var(--border)',
                  background: 'var(--bg-soft)',
                  color: 'var(--text)'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = 'var(--violet)';
                  e.target.style.boxShadow = '0 0 0 4px rgba(124,58,237,.2)';
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = 'var(--border)';
                  e.target.style.boxShadow = 'none';
                }}
              />
            </div>
            
            <div>
              <label className="font-akira" style={{ fontSize: '12px', fontWeight: 700, marginBottom: '6px', display: 'block' }}>
                ID CODE
              </label>
              <input
                type="text"
                value={idCode}
                onChange={(e) => setIdCode(e.target.value)}
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  borderRadius: '12px',
                  border: '1px solid var(--border)',
                  background: 'var(--bg-soft)',
                  color: 'var(--text)'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = 'var(--violet)';
                  e.target.style.boxShadow = '0 0 0 4px rgba(124,58,237,.2)';
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = 'var(--border)';
                  e.target.style.boxShadow = 'none';
                }}
              />
            </div>
          </div>
          
          <div style={{ marginBottom: '14px' }}>
            <label className="font-akira" style={{ fontSize: '12px', fontWeight: 700, marginBottom: '6px', display: 'block' }}>
              NUMBER
            </label>
            <input
              type="number"
              value={number}
              onChange={(e) => setNumber(e.target.value)}
              placeholder="#123"
              style={{
                width: '100%',
                padding: '12px 14px',
                borderRadius: '12px',
                border: '1px solid var(--border)',
                background: 'var(--bg-soft)',
                color: 'var(--text)'
              }}
              onFocus={(e) => {
                e.target.style.borderColor = 'var(--violet)';
                e.target.style.boxShadow = '0 0 0 4px rgba(107,0,216,.2)';
              }}
              onBlur={(e) => {
                e.target.style.borderColor = 'var(--border)';
                e.target.style.boxShadow = 'none';
              }}
            />
          </div>
          
          <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
            <button
              type="submit"
              className="karma-btn font-akira"
              style={{
                padding: '12px 24px',
                background: 'var(--violet)',
                color: 'white',
                border: 'none'
              }}
            >
              SEARCH
            </button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
