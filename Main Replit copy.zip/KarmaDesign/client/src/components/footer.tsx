import { SiInstagram, SiTiktok, SiFacebook } from "react-icons/si";
import { Play } from "lucide-react";

export function Footer() {
  return (
    <footer style={{
      borderTop: '1px solid var(--border)',
      background: 'var(--bg)',
      padding: '24px'
    }}>
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '12px',
        flexWrap: 'wrap'
      }}>
        <div style={{ display: 'flex', gap: '6px' }}>
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram"
            style={{
              display: 'inline-flex',
              width: '36px',
              height: '36px',
              alignItems: 'center',
              justifyContent: 'center',
              border: '1px solid var(--border)',
              borderRadius: '10px',
              color: 'var(--text)',
              textDecoration: 'none',
              transition: 'border-color .18s ease, box-shadow .18s ease'
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.borderColor = 'var(--violet)';
              e.currentTarget.style.boxShadow = '0 0 0 6px rgba(107,0,216,.22)';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.borderColor = 'var(--border)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            <SiInstagram />
          </a>
          <a
            href="https://tiktok.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="TikTok"
            style={{
              display: 'inline-flex',
              width: '36px',
              height: '36px',
              alignItems: 'center',
              justifyContent: 'center',
              border: '1px solid var(--border)',
              borderRadius: '10px',
              color: 'var(--text)',
              textDecoration: 'none',
              transition: 'border-color .18s ease, box-shadow .18s ease'
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.borderColor = 'var(--violet)';
              e.currentTarget.style.boxShadow = '0 0 0 6px rgba(107,0,216,.22)';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.borderColor = 'var(--border)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            <SiTiktok />
          </a>
          <a
            href="https://facebook.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Facebook"
            style={{
              display: 'inline-flex',
              width: '36px',
              height: '36px',
              alignItems: 'center',
              justifyContent: 'center',
              border: '1px solid var(--border)',
              borderRadius: '10px',
              color: 'var(--text)',
              textDecoration: 'none',
              transition: 'border-color .18s ease, box-shadow .18s ease'
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.borderColor = 'var(--violet)';
              e.currentTarget.style.boxShadow = '0 0 0 6px rgba(107,0,216,.22)';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.borderColor = 'var(--border)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            <SiFacebook />
          </a>
          <a
            href="https://youtube.com/@karmaarts/shorts"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="YouTube Shorts"
            style={{
              display: 'inline-flex',
              width: '36px',
              height: '36px',
              alignItems: 'center',
              justifyContent: 'center',
              border: '1px solid var(--border)',
              borderRadius: '10px',
              color: 'var(--text)',
              textDecoration: 'none',
              transition: 'border-color .18s ease, box-shadow .18s ease'
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.borderColor = 'var(--violet)';
              e.currentTarget.style.boxShadow = '0 0 0 6px rgba(107,0,216,.22)';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.borderColor = 'var(--border)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            <Play className="h-4 w-4" />
          </a>
        </div>
        <div style={{ color: 'var(--muted)' }}>© 2025 Karma</div>
      </div>
    </footer>
  );
}
