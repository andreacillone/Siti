# Overview

Karma is a premium e-commerce web application for showcasing and selling collectible framed artworks featuring authentic Hot Wheels die-cast cars. The platform presents a modern, minimal aesthetic inspired by Japanese tuning culture, offering a curated gallery of unique one-of-a-kind pieces. The application features a multi-page experience with homepage, gallery, individual product pages, support section, search functionality, user accounts, shopping cart, payment processing (Stripe/PayPal), and comprehensive admin panel.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The frontend is built using **React 18** with **TypeScript** and follows a component-based architecture. Key architectural decisions include:

- **Routing**: Uses Wouter for lightweight client-side routing, chosen over React Router for its minimal bundle size and simplicity
- **State Management**: Leverages TanStack Query (React Query) for server state management, eliminating the need for complex global state solutions
- **Styling**: Implements Tailwind CSS with shadcn/ui components for consistent design system and rapid development
- **Theme System**: Custom theme provider supporting light/dark modes with CSS variables and local storage persistence
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

## Backend Architecture

The backend follows a **REST API** pattern built with Express.js and TypeScript:

- **Server Framework**: Express.js with middleware for JSON parsing, CORS, and request logging
- **API Structure**: RESTful endpoints under `/api` prefix for products and search functionality
- **Error Handling**: Centralized error middleware with proper HTTP status codes
- **Storage Layer**: Abstracted storage interface allowing for easy swapping between in-memory and database implementations
- **Development Setup**: Vite integration for hot module replacement and development tooling

## Data Storage Solutions

The application uses a **hybrid storage approach**:

- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Management**: Centralized schema definitions using Drizzle with Zod validation
- **Development Storage**: In-memory storage implementation for rapid prototyping and testing
- **Migration Strategy**: Drizzle Kit for database migrations and schema updates

## Authentication and Authorization

Implements a **comprehensive authentication system**:

- **User Accounts**: Full login/registration system with Google authentication support
- **Admin Panel**: Complete administrative interface for managing products, orders, and users
- **Session Management**: Secure session handling and user state management
- **Role-based Access**: Different access levels for customers and administrators

## External Dependencies

### Database and Infrastructure
- **Neon Database**: Serverless PostgreSQL database using `@neondatabase/serverless`
- **Drizzle ORM**: Type-safe database toolkit for PostgreSQL operations
- **Drizzle Kit**: Database migration and introspection tool

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Radix UI**: Unstyled, accessible UI primitives for complex components
- **shadcn/ui**: Pre-built component library based on Radix UI and Tailwind
- **Lucide React**: Icon library for consistent iconography
- **React Icons**: Additional icon sets including social media icons

### Development and Build Tools
- **Vite**: Fast build tool and development server
- **TypeScript**: Type safety across the entire application
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer

### Frontend Libraries
- **TanStack Query**: Server state management and caching
- **Wouter**: Lightweight routing library
- **React Hook Form**: Performant form library with minimal re-renders
- **Hookform Resolvers**: Zod integration for form validation
- **Class Variance Authority**: Utility for creating variant-based component APIs
- **CLSX**: Conditional className utility
- **Date-fns**: Date manipulation and formatting

### Font and Typography
- **Google Fonts**: Orbitron and Archivo Black for brand typography
- **Lucide React**: Modern icon library for UI elements and navigation

## Recent Updates (January 2025)

### E-commerce Features Added
✓ User account system with login/registration and Google Auth integration
✓ Shopping cart functionality with item management
✓ Multi-payment support (Stripe, PayPal, Google Pay)
✓ Order processing and checkout system

### Admin Panel Implementation
✓ Complete administrative interface with tabs for Products, Orders, Users, and Settings
✓ Product management: create, edit, delete, and visibility controls
✓ Order tracking and status management
✓ User management with role-based permissions
✓ Site settings configuration including payment methods and social media links
✓ Image and video URL management for products

### UI/UX Improvements
✓ Refined navbar with improved cart and theme toggle icons using Lucide React
✓ Gallery filtering system (Available/Sold Out status)
✓ Enhanced search modal with better user experience
✓ Consistent violet (#6b00d8) color scheme removing all blue references
✓ Responsive design optimizations