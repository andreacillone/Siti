import img1 from "@/assets/gallery-1.jpg";
import img2 from "@/assets/gallery-2.jpg";
import img3 from "@/assets/gallery-3.jpg";
import img4 from "@/assets/gallery-4.jpg";

export type ProductItem = {
  slug: string;
  name: string;
  year: number;
  available: boolean;
  images: string[];
  frameUsed: string;
  dimensions: string;
  idCode: string;
  videoLinks?: { type: 'instagram'|'tiktok'|'facebook'; url: string }[];
};

export const products: ProductItem[] = [
  { slug: 'datsun-510', name: 'DATSUN', year: 2025, available: true, images: [img1, img2, img3], frameUsed: 'SANNAHED 13×18', dimensions: '22×26×6 cm', idCode: 'KAR25001' },
  { slug: 'supra', name: 'SUPRA', year: 2025, available: false, images: [img2, img1, img4], frameUsed: 'SANNAHED 13×18', dimensions: '22×26×6 cm', idCode: 'KAR25002' },
  { slug: 'rx7', name: 'RX-7', year: 2025, available: true, images: [img3, img1, img4], frameUsed: 'SANNAHED 13×18', dimensions: '22×26×6 cm', idCode: 'KAR25003' },
  { slug: 'gtr', name: 'GTR', year: 2025, available: true, images: [img4, img2, img1], frameUsed: 'SANNAHED 13×18', dimensions: '22×26×6 cm', idCode: 'KAR25004' },
  { slug: 'silvia', name: 'SILVIA', year: 2025, available: false, images: [img1, img3, img2], frameUsed: 'SANNAHED 13×18', dimensions: '22×26×6 cm', idCode: 'KAR25005' },
  { slug: '86', name: 'AE86', year: 2025, available: true, images: [img2, img3, img4], frameUsed: 'SANNAHED 13×18', dimensions: '22×26×6 cm', idCode: 'KAR25006' },
];
