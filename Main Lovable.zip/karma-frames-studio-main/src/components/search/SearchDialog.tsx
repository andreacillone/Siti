import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { X } from "lucide-react";

export type SearchParams = { name?: string; id?: string; number?: string };

export const SearchDialog = ({ open, onOpenChange, onSearch }: { open: boolean; onOpenChange: (v: boolean) => void; onSearch: (params: SearchParams) => void }) => {
  const [name, setName] = useState("");
  const [id, setId] = useState("");
  const [number, setNumber] = useState("");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-akira tracking-widest">Search</DialogTitle>
        </DialogHeader>
        <DialogClose className="absolute right-4 top-4 rounded-md p-1 hover:bg-muted/60" aria-label="Close">
          <X className="h-4 w-4" />
        </DialogClose>
        <div className="grid gap-3">
          <Input placeholder="Car Name" value={name} onChange={(e)=>setName(e.target.value)} />
          <div className="grid grid-cols-2 gap-3">
            <Input placeholder="ID Code" value={id} onChange={(e)=>setId(e.target.value)} />
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">#</span>
              <Input className="pl-7" inputMode="numeric" pattern="[0-9]*" placeholder="Number" value={number} onChange={(e)=>setNumber(e.target.value.replace(/\D/g,''))} />
            </div>
          </div>
          <Button variant="hero" onClick={() => onSearch({ name, id, number })}>Search</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
