import { useEffect, useState } from "react";
import { Switch } from "@/components/ui/switch";

export const ThemeToggle = () => {
  const [dark, setDark] = useState<boolean>(() => {
    return typeof window !== 'undefined' && document.documentElement.classList.contains('dark');
  });

  useEffect(() => {
    if (dark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [dark]);

  useEffect(() => {
    const saved = localStorage.getItem('theme');
    if (saved) setDark(saved === 'dark');
  }, []);

  return (
    <Switch checked={dark} onCheckedChange={setDark} aria-label="Toggle theme" />
  );
};
