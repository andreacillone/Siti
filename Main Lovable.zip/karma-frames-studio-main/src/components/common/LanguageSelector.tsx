import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export const LanguageSelector = () => {
  const [lang, setLang] = useState<'US' | 'IT' | 'SP'>("US");
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" aria-label="Language">
          {lang}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-40">
        <div className="flex flex-col gap-1">
          {['US','IT','SP'].map((l) => (
            <button
              key={l}
              onClick={() => setLang(l as 'US' | 'IT' | 'SP')}
              className={`text-left px-2 py-1 rounded-md ${lang===l? 'bg-muted' : 'hover:bg-muted/60'}`}
            >
              {l}
            </button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
};
