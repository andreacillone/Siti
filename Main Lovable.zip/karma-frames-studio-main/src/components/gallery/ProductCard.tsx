import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";

export type Product = {
  slug: string;
  name: string;
  year: number;
  available: boolean;
  images: string[];
  frameUsed: string;
  dimensions: string;
  idCode: string;
  videoLinks?: { type: 'instagram'|'tiktok'|'facebook'; url: string }[];
};

export const ProductCard = ({ product, index }: { product: Product; index?: number }) => {
  const img = product.images[0];
  return (
    <Link to={`/product/${product.slug}`} className="block group">
      <Card className="overflow-hidden border hover:shadow-xl hover:shadow-brand/20 transition-shadow">
        <div className="aspect-square overflow-hidden">
          <img src={img} alt={`${product.name} framed artwork`} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform" />
        </div>
        <div className="p-4 flex items-center justify-between">
          <div className="font-akira tracking-widest text-sm">{product.name.toUpperCase()}</div>
          <div className={cn("text-xs px-2 py-1 rounded-full", product.available ? "bg-brand/10 text-brand" : "bg-muted text-muted-foreground")}>{product.available ? 'Available' : 'Sold Out'}</div>
        </div>
      </Card>
    </Link>
  );
};
