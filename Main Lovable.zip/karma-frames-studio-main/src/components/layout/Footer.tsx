import { useLocation } from "react-router-dom";

const socials = [
  { name: "Instagram", href: "https://instagram.com/" },
  { name: "TikTok", href: "https://tiktok.com/" },
  { name: "Facebook", href: "https://facebook.com/" },
  { name: "YouTube Shorts", href: "https://www.youtube.com/shorts" },
];

const InstagramIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <rect x="3" y="3" width="18" height="18" rx="5" ry="5" fill="none" stroke="currentColor" strokeWidth="2"/>
    <circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" strokeWidth="2"/>
    <circle cx="17.5" cy="6.5" r="1.2" fill="currentColor"/>
  </svg>
);
const TikTokIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <path d="M21 8.5c-2 0-4-1-5-2.7V16a5 5 0 1 1-3-4.6V14a3 3 0 1 0 3 3V3h2a6 6 0 0 0 3 3v2.5z" fill="currentColor"/>
  </svg>
);
const FacebookIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <path d="M14 9h3V6h-3c-1.7 0-3 1.3-3 3v2H8v3h3v7h3v-7h3l1-3h-4V9c0-.6.4-1 1-1z" fill="currentColor"/>
  </svg>
);
const YouTubeIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <path d="M21.6 7.2a3 3 0 0 0-2.1-2.1C18 4.6 12 4.6 12 4.6s-6 0-7.5.5a3 3 0 0 0-2.1 2.1C2 8.7 2 12 2 12s0 3.3.4 4.8a3 3 0 0 0 2.1 2.1C6 19.4 12 19.4 12 19.4s6 0 7.5-.5a3 3 0 0 0 2.1-2.1C22 15.3 22 12 22 12s0-3.3-.4-4.8z" fill="currentColor"/>
    <path d="M10 15V9l5 3-5 3z" fill="#fff"/>
  </svg>
);

export const Footer = () => {
  const { pathname } = useLocation();
  const hideSocials = pathname === "/support";
  return (
    <footer className="w-full border-t bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {!hideSocials && socials.map((s) => (
            <a key={s.name} href={s.href} target="_blank" rel="noreferrer" aria-label={s.name} className="p-2 rounded-md hover:bg-muted/60 transition-colors">
              {s.name === 'Instagram' && <InstagramIcon className="h-5 w-5" />}
              {s.name === 'TikTok' && <TikTokIcon className="h-5 w-5" />}
              {s.name === 'Facebook' && <FacebookIcon className="h-5 w-5" />}
              {s.name === 'YouTube Shorts' && <YouTubeIcon className="h-5 w-5" />}
            </a>
          ))}
        </div>
        <p className="text-sm text-muted-foreground">©2025 Karma</p>
      </div>
    </footer>
  );
};
