import { Link, NavLink, useNavigate } from "react-router-dom";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/common/ThemeToggle";
import { LanguageSelector } from "@/components/common/LanguageSelector";
import { SearchDialog } from "@/components/search/SearchDialog";
import { useState } from "react";

export const Navbar = () => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <header className="w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto h-14 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <Link to="/" className="font-akira text-xl tracking-widest">
            KARMA
          </Link>
          <nav className="hidden sm:flex items-center gap-5 text-sm">
            <NavLink to="/gallery" className={({isActive}) => isActive ? "text-primary font-semibold" : "text-foreground/80 hover:text-foreground"}>Gallery</NavLink>
            <NavLink to="/support" className={({isActive}) => isActive ? "text-primary font-semibold" : "text-foreground/80 hover:text-foreground"}>Support</NavLink>
            <button onClick={() => setOpen(true)} className="text-foreground/80 hover:text-foreground underline underline-offset-4">Search</button>
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" aria-label="Search" onClick={() => setOpen(true)}>
            <Search />
          </Button>
          <ThemeToggle />
          <LanguageSelector />
        </div>
      </div>
      <SearchDialog open={open} onOpenChange={setOpen} onSearch={(params) => {
        setOpen(false);
        const query = new URLSearchParams(params as any).toString();
        navigate(`/search?${query}`);
      }}/>
    </header>
  );
};
