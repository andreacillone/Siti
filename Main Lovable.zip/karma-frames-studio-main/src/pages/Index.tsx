import hero from "@/assets/hero-frame.jpg";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { HeadSEO } from "@/components/common/HeadSEO";

const Index = () => {
  return (
    <div className="min-h-screen grid grid-rows-[auto_1fr_auto]">
      <HeadSEO title="Karma — 1/1 Art Frames" description="One-of-one framed artworks using real Hot Wheels cars." canonical="/" />
      <Navbar />
      <main className="container mx-auto grid md:grid-cols-2 gap-8 items-center py-8 md:py-0 md:h-[calc(100vh-128px)]">
        <h1 className="sr-only">Karma — One-of-one Hot Wheels Art Frames</h1>
        <div className="rounded-xl overflow-hidden shadow-[0_20px_60px_-20px_hsl(var(--brand)/0.35)]">
          <img src={hero} alt="Karma framed Hot Wheels artwork" className="w-full h-full object-cover" />
        </div>
        <div className="flex items-center justify-center md:justify-start">
          <p className="font-akira text-3xl md:text-4xl tracking-widest text-foreground/90">1/1. No copies exist.</p>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Index;
