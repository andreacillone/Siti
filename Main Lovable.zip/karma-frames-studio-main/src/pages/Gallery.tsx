import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { HeadSEO } from "@/components/common/HeadSEO";
import { useState, useMemo } from "react";
import { ProductCard } from "@/components/gallery/ProductCard";
import { products as all } from "@/data/products";
import { Button } from "@/components/ui/button";

const Gallery = () => {
  const [visible, setVisible] = useState(6);
  const [filter, setFilter] = useState<'all'|'available'|'soldout'>('all');

  const filtered = useMemo(() => {
    if (filter === 'available') return all.filter(p => p.available);
    if (filter === 'soldout') return all.filter(p => !p.available);
    return all;
  }, [filter]);

  const products = filtered.slice(0, visible);

  return (
    <div className="min-h-screen grid grid-rows-[auto_1fr_auto]">
      <HeadSEO title="Karma — Gallery" description="Discover one-of-one framed artworks built with real Hot Wheels cars." canonical="/gallery" />
      <Navbar />
      <main className="container mx-auto py-8">
        <h1 className="sr-only">Karma Gallery</h1>
        <div className="mb-6 flex gap-2">
          {[
            {key:'all', label:'All'},
            {key:'available', label:'Available'},
            {key:'soldout', label:'Sold Out'}
          ].map(({key,label}) => (
            <button
              key={key}
              onClick={() => { setFilter(key as any); setVisible(6); }}
              className={`px-3 py-1.5 rounded-md border text-sm transition-colors ${filter===key ? 'bg-card' : 'hover:bg-card'}`}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((p, i) => (
            <ProductCard key={p.slug} product={p} index={i} />
          ))}
        </div>
        {visible < filtered.length && (
          <div className="flex justify-center mt-8">
            <Button variant="hero" onClick={() => setVisible((v)=>v+3)}>Load More</Button>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default Gallery;
