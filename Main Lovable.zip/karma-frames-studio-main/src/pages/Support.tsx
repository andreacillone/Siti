import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { HeadSEO } from "@/components/common/HeadSEO";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const faqs = [
  { q: 'What is Karma?', a: 'A premium art brand creating one-of-one framed artworks using real Hot Wheels cars.' },
  { q: 'Are there duplicates?', a: 'No. Each frame is unique: 1/1.' },
  { q: 'How can I buy?', a: 'Follow us on social to know when drops happen.' },
  { q: 'Do you ship worldwide?', a: 'Yes.' },
];

const Support = () => {
  return (
    <div className="min-h-screen grid grid-rows-[auto_1fr_auto]">
      <HeadSEO title="Karma — Support" description="Get in touch with Karma. Support hours and FAQs." canonical="/support" />
      <Navbar />
      <main className="container mx-auto py-10 grid lg:grid-cols-2 gap-10">
        <section>
          <h1 className="font-akira text-2xl tracking-widest mb-4">Karma Support — Contact Us</h1>
          <p className="mb-4">karmaprojects2@gmail.com</p>
          <div className="space-y-1 text-sm text-muted-foreground">
            <div>Customer Support Hours</div>
            <div>Monday – Saturday, 08:00–19:00 (UTC+1)</div>
          </div>
          <div className="mt-6 text-sm text-muted-foreground">
            Social: Instagram, TikTok, Facebook, Vinted
          </div>
        </section>
        <section>
          <h2 className="font-akira text-xl tracking-widest mb-4">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible>
            {faqs.map((f,i)=> (
              <AccordionItem key={i} value={`faq-${i}`}>
                <AccordionTrigger>{f.q}</AccordionTrigger>
                <AccordionContent>{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Support;
