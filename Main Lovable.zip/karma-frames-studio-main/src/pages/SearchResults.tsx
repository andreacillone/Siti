import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { HeadSEO } from "@/components/common/HeadSEO";
import { products } from "@/data/products";
import { useLocation, Link } from "react-router-dom";

const useQuery = () => new URLSearchParams(useLocation().search);

const SearchResults = () => {
  const q = useQuery();
  const name = (q.get('name') || '').toLowerCase();
  const id = (q.get('id') || '').toLowerCase();
  const number = (q.get('number') || '').toLowerCase();

  const results = products.filter(p => {
    const nameMatch = name ? p.name.toLowerCase().includes(name) : true;
    const idMatch = id ? p.idCode.toLowerCase().includes(id) : true;
    const numberMatch = number ? p.idCode.toLowerCase().includes(number) : true;
    return nameMatch && idMatch && numberMatch;
  });

  const title = results.length ? `Karma — ${results.length} result(s)` : 'Karma — No results';

  return (
    <div className="min-h-screen grid grid-rows-[auto_1fr_auto]">
      <HeadSEO title={title} description="Search results" canonical="/search" />
      <Navbar />
      <main className="container mx-auto py-10">
        <h1 className="sr-only">Search Results</h1>
        {results.length ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {results.map((p) => (
              <Link key={p.slug} to={`/product/${p.slug}`} className="group">
                <div className="rounded-lg overflow-hidden border">
                  <img src={p.images[0]} alt={`${p.name} frame`} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                </div>
                <div className="mt-2 font-akira tracking-widest text-sm">{p.name}</div>
              </Link>
            ))}
          </div>
        ) : (
          <p className="text-center text-muted-foreground">No results found. Please check your search and try again.</p>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default SearchResults;
