import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { HeadSEO } from "@/components/common/HeadSEO";
import { useMemo } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { products } from "@/data/products";
import { Button } from "@/components/ui/button";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const ProductPage = () => {
  const { slug } = useParams();
  const index = products.findIndex(p => p.slug === slug);
  const product = useMemo(() => products.find(p=>p.slug===slug), [slug]);
  const navigate = useNavigate();

  if (!product) return (
    <div className="min-h-screen grid grid-rows-[auto_1fr_auto]">
      <Navbar />
      <main className="container mx-auto py-12">Product not found.</main>
      <Footer />
    </div>
  );

  const next = products[(index + 1) % products.length];

  return (
    <div className="min-h-screen grid grid-rows-[auto_1fr_auto]">
      <HeadSEO title={`Karma — ${product.name}`} description={`${product.name} — one-of-one framed artwork.`} canonical={`/product/${product.slug}`} />
      <Navbar />
      <main className="container mx-auto py-8">
        <div className="flex items-center justify-between mb-6">
          <button className="text-sm underline underline-offset-4" onClick={()=>navigate('/gallery')}>Back to Gallery</button>
          <button className="text-sm underline underline-offset-4" onClick={()=>navigate(`/product/${next.slug}`)}>Next product</button>
        </div>
        <div className="grid lg:grid-cols-2 gap-10 items-start">
          <div className="relative rounded-xl overflow-hidden">
            <Carousel className="w-full">
              <CarouselContent>
                {product.images.map((src, i) => (
                  <CarouselItem key={i}>
                    <img src={src} alt={`${product.name} view ${i+1}`} className="w-full h-full object-cover rounded-xl" />
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious />
              <CarouselNext />
            </Carousel>
          </div>
          <div className="space-y-4">
            <h1 className="font-akira text-2xl md:text-3xl tracking-widest">{product.name.toUpperCase()}</h1>
            <p className="text-muted-foreground">{product.year}</p>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="frame">
                <AccordionTrigger>Frame Used</AccordionTrigger>
                <AccordionContent>{product.frameUsed}</AccordionContent>
              </AccordionItem>
              <AccordionItem value="dimensions">
                <AccordionTrigger>Total Dimensions</AccordionTrigger>
                <AccordionContent>{product.dimensions}</AccordionContent>
              </AccordionItem>
              <AccordionItem value="id">
                <AccordionTrigger>ID Code</AccordionTrigger>
                <AccordionContent>{product.idCode}</AccordionContent>
              </AccordionItem>
              <AccordionItem value="videos">
                <AccordionTrigger>Video Links</AccordionTrigger>
                <AccordionContent>
                  <div className="flex gap-3">
                    {(product.videoLinks ?? [
                      { type: 'instagram' as const, url: 'https://instagram.com/' },
                      { type: 'tiktok' as const, url: 'https://tiktok.com/' },
                      { type: 'facebook' as const, url: 'https://facebook.com/' },
                    ]).map((v) => (
                      <a key={v.type} href={v.url} target="_blank" rel="noreferrer" className="px-3 py-2 rounded-md bg-muted hover:bg-muted/70 text-sm">{v.type}</a>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ProductPage;
